**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex.slice throttled 1418 of 1418 periods (1080.6 s stopped); load1 up to 21.4 (> 8.0)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| plain-100 | 100 | letter@middle | 19 | 26.9 / 72.7 / 89.9 | p95 | 11 | 72.7 | 403.5 | 63.9 | 19/19 | 2 / 2 | 227 MB | 17.22-17.61 | MISS: p95 72.7 ms > 11 ms |
| plain-100 | 100 | typing@100ms | 39 | 14.1 / 80.4 / 106.4 | p95 | 11 | - | - | 66.5 | - | - | 227 MB | 17.61-17.61 | MISS: p95 80.4 ms > 11 ms |
| plain-100 | 100 | typing@150ms | 39 | 17.1 / 35.5 / 103.0 | p95 | 11 | - | - | 19.6 | - | - | 227 MB | 17.61-17.83 | MISS: p95 35.5 ms > 11 ms |
| full-1000 | 1002 | letter@middle | 19 | 104.0 / 167.2 / 179.1 | p95 | 11 | 167.2 | 1385.7 | 139.4 | 19/19 | 33 / 33 | 1431 MB | 17.83-21.03 | MISS: p95 167.2 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 39.7 / 194.4 / 304.8 | p95 | 11 | - | - | 75.0 | - | - | 1431 MB | 21.03-21.03 | MISS: p95 194.4 ms > 11 ms; 3 of 39 keystrokes not painted by their own compile |
| full-1000 | 1002 | typing@150ms | 39 | 93.4 / 169.9 / 306.6 | p95 | 11 | - | - | 132.8 | - | - | 1431 MB | 21.03-21.42 | MISS: p95 169.9 ms > 11 ms; 1 of 39 keystrokes not painted by their own compile |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
