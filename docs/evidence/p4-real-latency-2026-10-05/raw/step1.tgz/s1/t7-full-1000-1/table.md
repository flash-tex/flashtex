**NON-REFERENCE run**: power source unknown at start; power source unknown at end; load1 up to 10.1 (> 8.0)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@middle | 19 | 25.8 / 70.2 / 72.4 | p95 | 11 | 70.2 | 884.5 | 19/19 | 33 / 33 | 1417 MB | 6.74-10.09 | MISS: p95 70.2 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1). The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
