**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | preamble | 5 | 401.6 / 426.0 / 426.0 | max | 400 | 426.0 | 1766.8 | 2.2 | 0/5 | 58 / 58 | 222 MB | 0.55-0.72 | MISS: max 426.0 ms > 400 ms |
| beamer-30 | 58 | reopen: host's share, cold (spawn -> page 1) | 3 | 151.0 / 154.1 / 154.1 | max | (100, app) | - | - | - | - | - | 222 MB | 0.72-0.74 | report-only: max 154.1 ms > 100 ms |
| beamer-30 | 58 | reopen: host already listening (not counted, decision 8) | 3 | 98.6 / 100.9 / 100.9 | max | (100, app) | - | - | - | - | - | 222 MB | 0.72-0.74 | report-only: max 100.9 ms > 100 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
