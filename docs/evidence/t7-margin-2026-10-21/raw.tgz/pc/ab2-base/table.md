**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.3 / 9.6 / 10.4 | p95 | 11 | 9.6 | 39.5 | 0.1 | 19/19 | 2 / 2 | 189 MB | 0.65-0.55 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.5 / 9.6 / 9.9 | p95 | 11 | 3.9 | 36.9 | 0.0 | 19/19 | 3 / 3 | 189 MB | 0.55-0.51 | PASS |
| full-10 | 11 | sentence@middle | 19 | 8.6 / 9.2 / 10.0 | p95 | 11 | 3.5 | 53.8 | 0.0 | 0/19 | 7 / 7 | 189 MB | 0.51-0.47 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.2 / 8.8 / 9.9 | p95 | 11 | - | - | 0.0 | - | - | 189 MB | 0.47-0.51 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.2 / 8.6 / 9.4 | p95 | 11 | - | - | 0.0 | - | - | 189 MB | 0.51-0.55 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.1 / 11.0 / 13.2 | p95 | 11 | 11.0 | 58.4 | 0.1 | 19/19 | 2 / 2 | 202 MB | 0.55-0.47 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 9.0 / 10.8 / 10.8 | p95 | 11 | 10.8 | 57.4 | 0.1 | 19/19 | 2 / 2 | 202 MB | 0.47-0.43 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.5 / 10.5 / 13.2 | p95 | 11 | 10.5 | 54.8 | 0.1 | 19/19 | 2 / 2 | 202 MB | 0.43-0.44 | PASS |
| beamer-30 | 58 | typing@60ms | 39 | 8.5 / 9.2 / 17.4 | p95 | 11 | - | - | 0.1 | - | - | 202 MB | 0.44-0.44 | PASS |
| beamer-30 | 58 | typing@100ms | 39 | 8.6 / 10.3 / 10.5 | p95 | 11 | - | - | 0.1 | - | - | 202 MB | 0.44-0.41 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 9.0 / 10.5 / 10.5 | p95 | 11 | 10.5 | 317.9 | 0.1 | 19/19 | 33 / 33 | 690 MB | 0.41-0.73 | PASS |
| full-1000 | 1002 | letter@start | 19 | 10.0 / 11.5 / 11.6 | p95 | 11 | 11.5 | 82.0 | 0.1 | 19/19 | 2 / 2 | 690 MB | 0.73-0.67 | MISS: p95 11.5 ms > 11 ms |
| full-1000 | 1002 | letter@middle | 19 | 9.7 / 10.4 / 10.6 | p95 | 11 | 10.4 | 323.8 | 0.1 | 19/19 | 33 / 33 | 690 MB | 0.67-0.59 | PASS |
| full-1000 | 1002 | typing@60ms | 39 | 10.9 / 14.8 / 18.5 | p95 | 11 | - | - | 2.4 | - | - | 690 MB | 0.59-0.59 | MISS: p95 14.8 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 10.7 / 11.1 / 11.5 | p95 | 11 | - | - | 0.5 | - | - | 690 MB | 0.59-0.62 | MISS: p95 11.1 ms > 11 ms |
| plain-10 | 10 | sentence@middle | 19 | 4.0 / 4.6 / 4.6 | p95 | 11 | 2.1 | 28.5 | 0.0 | 0/19 | 6 / 6 | 130 MB | 0.62-0.53 | PASS |
| plain-10 | 10 | letter@start | 19 | 5.0 / 5.6 / 6.3 | p95 | 11 | 5.6 | 24.2 | 0.0 | 19/19 | 2 / 2 | 130 MB | 0.53-0.48 | PASS |
| plain-10 | 10 | letter@middle | 19 | 4.0 / 4.7 / 4.8 | p95 | 11 | 2.3 | 24.0 | 0.0 | 19/19 | 3 / 3 | 130 MB | 0.48-0.45 | PASS |
| plain-10 | 10 | typing@60ms | 39 | 3.8 / 4.1 / 4.4 | p95 | 11 | - | - | 0.0 | - | - | 130 MB | 0.45-0.57 | PASS |
| plain-10 | 10 | typing@100ms | 39 | 3.9 / 4.6 / 12.6 | p95 | 11 | - | - | 0.0 | - | - | 130 MB | 0.57-0.57 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
