**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 9.1 / 10.8 / 13.2 | p95 | 11 | 10.8 | 58.2 | 0.1 | 19/19 | 2 / 2 | 208 MB | 0.79-0.75 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.3 / 11.0 / 13.0 | p95 | 11 | 11.0 | 57.5 | 0.1 | 19/19 | 2 / 2 | 208 MB | 0.75-0.69 | MISS: p95 11.0 ms > 11 ms |
| beamer-30 | 58 | sentence@middle | 19 | 9.1 / 10.4 / 10.7 | p95 | 11 | 10.4 | 62.0 | 0.1 | 19/19 | 2 / 2 | 208 MB | 0.69-0.66 | PASS |
| beamer-30 | 58 | typing@60ms | 39 | 8.5 / 9.8 / 11.0 | p95 | 11 | - | - | 0.1 | - | - | 208 MB | 0.66-0.66 | PASS |
| beamer-5 | 5 | letter@middle | 19 | 3.8 / 4.7 / 5.2 | p95 | 11 | 4.7 | 36.4 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.66-0.93 | PASS |
| beamer-5 | 5 | sentence@middle | 19 | 3.8 / 4.6 / 4.7 | p95 | 11 | 4.6 | 35.6 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.93-0.94 | PASS |
| beamer-5 | 5 | letter@start | 19 | 3.9 / 4.7 / 5.2 | p95 | 11 | 4.7 | 36.7 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.94-0.79 | PASS |
| beamer-5 | 5 | typing@60ms | 39 | 3.5 / 3.9 / 4.0 | p95 | 11 | - | - | 0.0 | - | - | 170 MB | 0.79-0.79 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
