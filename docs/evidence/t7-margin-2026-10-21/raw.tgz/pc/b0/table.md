**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.8 / 10.8 / 11.1 | p95 | 11 | 10.8 | 41.3 | 0.1 | 19/19 | 2 / 2 | 188 MB | 2.67-2.5 | PASS |
| full-10 | 11 | letter@middle | 19 | 9.1 / 10.1 / 10.2 | p95 | 11 | 4.1 | 38.4 | 0.0 | 19/19 | 3 / 3 | 188 MB | 2.5-2.38 | PASS |
| full-10 | 11 | sentence@middle | 19 | 9.5 / 10.2 / 13.1 | p95 | 11 | 4.4 | 56.6 | 0.0 | 0/19 | 7 / 7 | 188 MB | 2.38-2.26 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.4 / 8.7 / 9.2 | p95 | 11 | - | - | 0.0 | - | - | 188 MB | 2.26-2.24 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.6 / 9.0 / 9.1 | p95 | 11 | - | - | 0.0 | - | - | 188 MB | 2.24-2.22 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.7 / 10.8 / 13.4 | p95 | 11 | 10.8 | 56.5 | 0.1 | 19/19 | 2 / 2 | 197 MB | 2.22-2.11 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 10.0 / 10.8 / 11.0 | p95 | 11 | 10.8 | 60.2 | 0.1 | 19/19 | 2 / 2 | 197 MB | 2.11-2.18 | PASS |
| beamer-30 | 58 | letter@start | 19 | 10.3 / 11.5 / 14.2 | p95 | 11 | 11.5 | 56.6 | 0.1 | 19/19 | 2 / 2 | 197 MB | 2.18-2.07 | MISS: p95 11.5 ms > 11 ms |
| beamer-30 | 58 | typing@60ms | 39 | 8.5 / 9.0 / 16.6 | p95 | 11 | - | - | 0.1 | - | - | 197 MB | 2.07-2.07 | PASS |
| beamer-30 | 58 | typing@100ms | 39 | 9.0 / 9.7 / 9.9 | p95 | 11 | - | - | 0.1 | - | - | 197 MB | 2.07-1.99 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 10.3 / 11.2 / 11.5 | p95 | 11 | 11.2 | 335.9 | 0.1 | 19/19 | 33 / 33 | 685 MB | 1.99-1.75 | MISS: p95 11.2 ms > 11 ms |
| full-1000 | 1002 | letter@start | 19 | 10.6 / 11.5 / 12.1 | p95 | 11 | 11.5 | 83.9 | 0.1 | 19/19 | 2 / 2 | 685 MB | 1.75-1.64 | MISS: p95 11.5 ms > 11 ms |
| full-1000 | 1002 | letter@middle | 19 | 9.8 / 11.0 / 11.1 | p95 | 11 | 11.0 | 329.4 | 0.1 | 19/19 | 33 / 33 | 685 MB | 1.64-1.7 | MISS: p95 11.0 ms > 11 ms |
| full-1000 | 1002 | typing@60ms | 39 | 11.9 / 14.4 / 19.3 | p95 | 11 | - | - | 2.3 | - | - | 685 MB | 1.7-1.72 | MISS: p95 14.4 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 10.9 / 11.3 / 15.5 | p95 | 11 | - | - | 0.5 | - | - | 685 MB | 1.72-1.72 | MISS: p95 11.3 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
