**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | typing@60ms | 39 | 9.3 / 13.2 / 29.9 | p95 | 11 | - | - | 2.1 | - | - | 691 MB | 1.0-1.0 | MISS: p95 13.2 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 9.3 / 10.0 / 10.8 | p95 | 11 | - | - | 0.5 | - | - | 691 MB | 1.0-1.0 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
