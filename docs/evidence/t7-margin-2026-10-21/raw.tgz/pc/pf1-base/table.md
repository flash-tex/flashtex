**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 9.3 / 10.5 / 13.2 | p95 | 11 | 10.5 | 56.5 | 0.1 | 19/19 | 2 / 2 | 202 MB | 1.46-1.31 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.1 / 10.4 / 14.0 | p95 | 11 | 10.4 | 55.5 | 0.1 | 19/19 | 2 / 2 | 202 MB | 1.31-1.29 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 8.9 / 10.4 / 10.5 | p95 | 11 | 10.4 | 57.5 | 0.1 | 19/19 | 2 / 2 | 202 MB | 1.29-1.09 | PASS |
| beamer-30 | 58 | typing@60ms | 39 | 8.5 / 9.2 / 10.0 | p95 | 11 | - | - | 0.1 | - | - | 202 MB | 1.09-1.09 | PASS |
| beamer-5 | 5 | letter@middle | 19 | 3.8 / 4.9 / 5.0 | p95 | 11 | 4.9 | 36.9 | 0.0 | 19/19 | 2 / 2 | 170 MB | 1.08-0.99 | PASS |
| beamer-5 | 5 | sentence@middle | 19 | 3.7 / 4.5 / 4.7 | p95 | 11 | 4.5 | 36.1 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.99-0.91 | PASS |
| beamer-5 | 5 | letter@start | 19 | 3.9 / 4.9 / 5.1 | p95 | 11 | 4.9 | 36.1 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.91-0.85 | PASS |
| beamer-5 | 5 | typing@60ms | 39 | 3.5 / 3.8 / 6.0 | p95 | 11 | - | - | 0.0 | - | - | 170 MB | 0.85-0.85 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
