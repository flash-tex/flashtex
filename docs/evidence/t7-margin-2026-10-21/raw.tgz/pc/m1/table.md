**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.0 / 10.4 / 10.6 | p95 | 11 | 10.4 | 38.8 | 0.1 | 19/19 | 2 / 2 | 188 MB | 0.6-0.55 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.6 / 9.8 / 10.3 | p95 | 11 | 4.2 | 38.5 | 0.0 | 19/19 | 3 / 3 | 188 MB | 0.55-0.55 | PASS |
| full-10 | 11 | sentence@middle | 19 | 8.6 / 9.8 / 10.2 | p95 | 11 | 4.3 | 51.7 | 0.0 | 0/19 | 7 / 7 | 188 MB | 0.55-0.58 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.0 / 8.2 / 8.8 | p95 | 11 | - | - | 0.0 | - | - | 188 MB | 0.58-0.58 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.2 / 8.6 / 9.4 | p95 | 11 | - | - | 0.0 | - | - | 188 MB | 0.58-0.62 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.0 / 10.8 / 13.7 | p95 | 11 | 10.8 | 57.5 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.62-0.6 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 8.9 / 10.2 / 10.3 | p95 | 11 | 10.2 | 58.0 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.6-0.66 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.1 / 13.4 / 17.2 | p95 | 11 | 13.4 | 56.6 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.66-0.69 | MISS: p95 13.4 ms > 11 ms |
| beamer-30 | 58 | typing@60ms | 39 | 8.4 / 9.2 / 15.7 | p95 | 11 | - | - | 0.1 | - | - | 200 MB | 0.69-0.71 | PASS |
| beamer-30 | 58 | typing@100ms | 39 | 8.5 / 8.8 / 10.3 | p95 | 11 | - | - | 0.1 | - | - | 200 MB | 0.71-0.74 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 9.3 / 10.4 / 10.9 | p95 | 11 | 10.4 | 317.0 | 0.1 | 19/19 | 33 / 33 | 686 MB | 0.74-0.98 | PASS |
| full-1000 | 1002 | letter@start | 19 | 10.0 / 11.2 / 11.4 | p95 | 11 | 11.2 | 80.1 | 0.1 | 19/19 | 2 / 2 | 686 MB | 0.98-0.9 | MISS: p95 11.2 ms > 11 ms |
| full-1000 | 1002 | letter@middle | 19 | 9.2 / 10.1 / 10.4 | p95 | 11 | 10.1 | 319.5 | 0.1 | 19/19 | 33 / 33 | 686 MB | 0.9-0.76 | PASS |
| full-1000 | 1002 | typing@60ms | 39 | 9.8 / 11.1 / 11.5 | p95 | 11 | - | - | 0.4 | - | - | 686 MB | 0.76-0.78 | MISS: p95 11.1 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 10.3 / 11.1 / 11.7 | p95 | 11 | - | - | 0.5 | - | - | 686 MB | 0.78-0.72 | MISS: p95 11.1 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
