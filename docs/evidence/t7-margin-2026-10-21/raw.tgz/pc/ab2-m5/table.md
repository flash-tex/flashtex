**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 8.9 / 10.0 / 10.5 | p95 | 11 | 10.0 | 41.8 | 0.1 | 19/19 | 2 / 2 | 186 MB | 0.52-0.56 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.3 / 9.7 / 16.1 | p95 | 11 | 4.0 | 37.0 | 0.0 | 19/19 | 3 / 3 | 186 MB | 0.56-0.48 | PASS |
| full-10 | 11 | sentence@middle | 19 | 8.3 / 9.6 / 9.9 | p95 | 11 | 3.9 | 54.3 | 0.0 | 0/19 | 7 / 7 | 186 MB | 0.48-0.6 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.1 / 8.6 / 16.7 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 0.6-0.6 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.2 / 8.8 / 8.9 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 0.6-0.55 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 8.8 / 9.9 / 12.8 | p95 | 11 | 9.9 | 54.9 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.55-0.54 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 9.0 / 10.9 / 11.0 | p95 | 11 | 10.9 | 57.7 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.54-0.46 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.2 / 11.0 / 14.4 | p95 | 11 | 11.0 | 57.6 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.46-0.42 | MISS: p95 11.0 ms > 11 ms |
| beamer-30 | 58 | typing@60ms | 39 | 8.3 / 9.1 / 15.6 | p95 | 11 | - | - | 0.1 | - | - | 200 MB | 0.42-0.55 | PASS |
| beamer-30 | 58 | typing@100ms | 39 | 8.4 / 9.0 / 10.8 | p95 | 11 | - | - | 0.1 | - | - | 200 MB | 0.55-0.5 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 9.5 / 10.8 / 11.4 | p95 | 11 | 10.8 | 327.7 | 0.1 | 19/19 | 33 / 33 | 689 MB | 0.5-0.91 | PASS |
| full-1000 | 1002 | letter@start | 19 | 10.0 / 10.8 / 19.0 | p95 | 11 | 10.8 | 81.0 | 0.1 | 19/19 | 2 / 2 | 689 MB | 0.91-0.77 | PASS |
| full-1000 | 1002 | letter@middle | 19 | 9.6 / 10.6 / 10.7 | p95 | 11 | 10.6 | 316.0 | 0.1 | 19/19 | 33 / 33 | 689 MB | 0.77-0.65 | PASS |
| full-1000 | 1002 | typing@60ms | 39 | 9.2 / 10.3 / 13.6 | p95 | 11 | - | - | 0.4 | - | - | 689 MB | 0.65-0.68 | PASS |
| full-1000 | 1002 | typing@100ms | 39 | 9.6 / 10.2 / 10.3 | p95 | 11 | - | - | 0.5 | - | - | 689 MB | 0.68-0.7 | PASS |
| plain-10 | 10 | sentence@middle | 19 | 4.0 / 4.5 / 4.6 | p95 | 11 | 2.3 | 28.0 | 0.0 | 0/19 | 6 / 6 | 131 MB | 0.7-0.65 | PASS |
| plain-10 | 10 | letter@start | 19 | 5.1 / 5.5 / 6.2 | p95 | 11 | 5.5 | 25.3 | 0.0 | 19/19 | 2 / 2 | 131 MB | 0.65-0.62 | PASS |
| plain-10 | 10 | letter@middle | 19 | 4.4 / 4.8 / 5.0 | p95 | 11 | 2.4 | 23.3 | 0.0 | 19/19 | 3 / 3 | 131 MB | 0.62-0.65 | PASS |
| plain-10 | 10 | typing@60ms | 39 | 3.9 / 4.2 / 4.2 | p95 | 11 | - | - | 0.0 | - | - | 131 MB | 0.65-0.65 | PASS |
| plain-10 | 10 | typing@100ms | 39 | 4.0 / 5.0 / 6.7 | p95 | 11 | - | - | 0.0 | - | - | 131 MB | 0.65-0.6 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
