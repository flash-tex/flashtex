**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | preamble | 5 | 405.2 / 423.0 / 423.0 | max | 400 | 423.0 | 1764.0 | 2.1 | 0/5 | 58 / 58 | 209 MB | 0.79-0.84 | MISS: max 423.0 ms > 400 ms |
| beamer-30 | 58 | reopen: host's share, cold (spawn -> page 1) | 3 | 148.7 / 150.3 / 150.3 | max | (100, app) | - | - | - | - | - | 209 MB | 0.85-0.86 | report-only: max 150.3 ms > 100 ms |
| beamer-30 | 58 | reopen: host already listening (not counted, decision 8) | 3 | 97.0 / 98.6 / 98.6 | max | (100, app) | - | - | - | - | - | 209 MB | 0.85-0.86 | report-only |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
