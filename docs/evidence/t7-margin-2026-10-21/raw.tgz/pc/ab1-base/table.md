**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.1 / 10.1 / 10.3 | p95 | 11 | 10.1 | 40.5 | 0.1 | 19/19 | 2 / 2 | 186 MB | 1.98-1.9 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.7 / 10.1 / 10.6 | p95 | 11 | 4.3 | 39.0 | 0.0 | 19/19 | 3 / 3 | 186 MB | 1.9-1.68 | PASS |
| full-10 | 11 | sentence@middle | 19 | 8.7 / 9.8 / 16.5 | p95 | 11 | 4.1 | 55.6 | 0.0 | 0/19 | 7 / 7 | 186 MB | 1.68-1.55 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.0 / 8.8 / 9.3 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 1.55-1.55 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.2 / 8.5 / 9.4 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 1.55-1.5 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.0 / 10.5 / 12.9 | p95 | 11 | 10.5 | 56.5 | 0.1 | 19/19 | 2 / 2 | 197 MB | 1.5-1.32 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 8.9 / 9.9 / 10.8 | p95 | 11 | 9.9 | 56.5 | 0.1 | 19/19 | 2 / 2 | 197 MB | 1.32-1.21 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.4 / 10.5 / 12.9 | p95 | 11 | 10.5 | 55.3 | 0.1 | 19/19 | 2 / 2 | 197 MB | 1.21-1.2 | PASS |
| beamer-30 | 58 | typing@60ms | 39 | 8.6 / 11.3 / 17.2 | p95 | 11 | - | - | 0.7 | - | - | 197 MB | 1.2-1.26 | MISS: p95 11.3 ms > 11 ms |
| beamer-30 | 58 | typing@100ms | 39 | 8.6 / 10.7 / 11.4 | p95 | 11 | - | - | 0.1 | - | - | 197 MB | 1.26-1.16 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 9.1 / 10.8 / 11.3 | p95 | 11 | 10.8 | 318.5 | 0.1 | 19/19 | 33 / 33 | 683 MB | 1.16-1.17 | PASS |
| full-1000 | 1002 | letter@start | 19 | 10.2 / 10.9 / 11.3 | p95 | 11 | 10.9 | 81.2 | 0.1 | 19/19 | 2 / 2 | 683 MB | 1.17-1.22 | PASS |
| full-1000 | 1002 | letter@middle | 19 | 9.4 / 10.5 / 11.2 | p95 | 11 | 10.5 | 319.7 | 0.1 | 19/19 | 33 / 33 | 683 MB | 1.22-1.03 | PASS |
| full-1000 | 1002 | typing@60ms | 39 | 9.9 / 13.4 / 14.2 | p95 | 11 | - | - | 2.2 | - | - | 683 MB | 1.03-1.03 | MISS: p95 13.4 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 10.5 / 11.8 / 12.0 | p95 | 11 | - | - | 0.5 | - | - | 683 MB | 1.03-1.03 | MISS: p95 11.8 ms > 11 ms |
| plain-10 | 10 | sentence@middle | 19 | 4.0 / 4.3 / 4.6 | p95 | 11 | 2.0 | 27.8 | 0.0 | 0/19 | 6 / 6 | 131 MB | 1.03-0.95 | PASS |
| plain-10 | 10 | letter@start | 19 | 5.0 / 5.6 / 5.8 | p95 | 11 | 5.6 | 25.3 | 0.1 | 19/19 | 2 / 2 | 131 MB | 0.95-0.8 | PASS |
| plain-10 | 10 | letter@middle | 19 | 4.2 / 4.5 / 4.9 | p95 | 11 | 2.1 | 24.9 | 0.0 | 19/19 | 3 / 3 | 131 MB | 0.8-0.73 | PASS |
| plain-10 | 10 | typing@60ms | 39 | 3.9 / 4.1 / 4.7 | p95 | 11 | - | - | 0.0 | - | - | 131 MB | 0.73-0.73 | PASS |
| plain-10 | 10 | typing@100ms | 39 | 4.0 / 4.5 / 5.1 | p95 | 11 | - | - | 0.0 | - | - | 131 MB | 0.73-0.68 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
