**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.0 / 9.8 / 9.9 | p95 | 11 | 9.8 | 38.7 | 0.1 | 19/19 | 2 / 2 | 186 MB | 0.68-0.65 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.2 / 9.6 / 9.8 | p95 | 11 | 3.9 | 37.2 | 0.0 | 19/19 | 3 / 3 | 186 MB | 0.65-0.59 | PASS |
| full-10 | 11 | sentence@middle | 19 | 8.6 / 9.9 / 10.8 | p95 | 11 | 4.0 | 50.9 | 0.0 | 0/19 | 7 / 7 | 186 MB | 0.59-0.5 | PASS |
| full-10 | 11 | typing@60ms | 39 | 8.0 / 8.3 / 8.9 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 0.5-0.5 | PASS |
| full-10 | 11 | typing@100ms | 39 | 8.0 / 8.5 / 8.6 | p95 | 11 | - | - | 0.0 | - | - | 186 MB | 0.5-0.46 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 8.9 / 10.1 / 12.9 | p95 | 11 | 10.1 | 56.5 | 0.1 | 19/19 | 2 / 2 | 209 MB | 0.46-0.54 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 8.8 / 10.1 / 17.7 | p95 | 11 | 10.1 | 57.5 | 0.1 | 19/19 | 2 / 2 | 209 MB | 0.54-0.46 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.2 / 13.9 / 18.2 | p95 | 11 | 13.9 | 58.2 | 0.1 | 19/19 | 2 / 2 | 209 MB | 0.46-0.42 | MISS: p95 13.9 ms > 11 ms |
| beamer-30 | 58 | typing@60ms | 39 | 8.3 / 8.7 / 12.9 | p95 | 11 | - | - | 0.1 | - | - | 209 MB | 0.42-0.47 | PASS |
| beamer-30 | 58 | typing@100ms | 39 | 8.5 / 10.5 / 11.8 | p95 | 11 | - | - | 0.1 | - | - | 209 MB | 0.47-0.47 | PASS |
| full-1000 | 1002 | sentence@middle | 19 | 9.7 / 10.6 / 10.7 | p95 | 11 | 10.6 | 328.4 | 0.1 | 19/19 | 33 / 33 | 685 MB | 0.59-0.77 | PASS |
| full-1000 | 1002 | letter@start | 19 | 10.1 / 11.4 / 11.6 | p95 | 11 | 11.4 | 83.0 | 0.1 | 19/19 | 2 / 2 | 685 MB | 0.77-0.89 | MISS: p95 11.4 ms > 11 ms |
| full-1000 | 1002 | letter@middle | 19 | 9.3 / 10.4 / 10.4 | p95 | 11 | 10.4 | 316.3 | 0.1 | 19/19 | 33 / 33 | 685 MB | 0.89-0.83 | PASS |
| full-1000 | 1002 | typing@60ms | 39 | 9.2 / 10.2 / 17.0 | p95 | 11 | - | - | 0.4 | - | - | 685 MB | 0.83-0.85 | PASS |
| full-1000 | 1002 | typing@100ms | 39 | 9.6 / 10.2 / 12.5 | p95 | 11 | - | - | 0.5 | - | - | 685 MB | 0.85-0.85 | PASS |
| plain-10 | 10 | sentence@middle | 19 | 4.1 / 4.3 / 4.8 | p95 | 11 | 2.0 | 30.5 | 0.0 | 0/19 | 6 / 6 | 130 MB | 0.78-0.72 | PASS |
| plain-10 | 10 | letter@start | 19 | 4.9 / 5.1 / 6.1 | p95 | 11 | 5.1 | 24.3 | 0.0 | 19/19 | 2 / 2 | 130 MB | 0.72-0.66 | PASS |
| plain-10 | 10 | letter@middle | 19 | 4.3 / 4.8 / 4.9 | p95 | 11 | 2.5 | 22.9 | 0.0 | 19/19 | 3 / 3 | 130 MB | 0.66-0.71 | PASS |
| plain-10 | 10 | typing@60ms | 39 | 4.0 / 4.2 / 4.4 | p95 | 11 | - | - | 0.0 | - | - | 130 MB | 0.71-0.71 | PASS |
| plain-10 | 10 | typing@100ms | 39 | 3.9 / 4.8 / 7.0 | p95 | 11 | - | - | 0.0 | - | - | 130 MB | 0.71-0.65 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
