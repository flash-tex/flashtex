**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | preamble | 5 | 406.4 / 409.2 / 409.2 | max | 400 | 409.2 | 1739.6 | 2.0 | 0/5 | 58 / 58 | 227 MB | 0.68-0.75 | MISS: max 409.2 ms > 400 ms |
| beamer-30 | 58 | reopen: host's share, cold (spawn -> page 1) | 3 | 151.0 / 152.4 / 152.4 | max | (100, app) | - | - | - | - | - | 227 MB | 0.75-0.79 | report-only: max 152.4 ms > 100 ms |
| beamer-30 | 58 | reopen: host already listening (not counted, decision 8) | 3 | 99.4 / 99.8 / 99.8 | max | (100, app) | - | - | - | - | - | 227 MB | 0.75-0.79 | report-only |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
