**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 9.2 / 10.1 / 10.7 | p95 | 11 | 10.1 | 56.4 | 0.1 | 19/19 | 2 / 2 | 215 MB | 0.86-0.81 | PASS |
| beamer-30 | 58 | letter@middle | 19 | 9.3 / 10.5 / 11.5 | p95 | 11 | 10.5 | 55.6 | 0.1 | 19/19 | 2 / 2 | 215 MB | 0.81-0.68 | PASS |
| beamer-30 | 58 | sentence@middle | 19 | 9.1 / 10.2 / 10.3 | p95 | 11 | 10.2 | 58.4 | 0.1 | 19/19 | 2 / 2 | 215 MB | 0.68-0.63 | PASS |
| beamer-30 | 58 | typing@60ms | 39 | 8.4 / 9.3 / 11.1 | p95 | 11 | - | - | 0.1 | - | - | 215 MB | 0.63-0.66 | PASS |
| beamer-5 | 5 | letter@middle | 19 | 3.6 / 4.5 / 5.0 | p95 | 11 | 4.5 | 35.4 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.66-0.68 | PASS |
| beamer-5 | 5 | sentence@middle | 19 | 3.7 / 4.6 / 4.6 | p95 | 11 | 4.6 | 38.1 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.68-0.65 | PASS |
| beamer-5 | 5 | letter@start | 19 | 3.6 / 4.2 / 5.0 | p95 | 11 | 4.2 | 38.4 | 0.0 | 19/19 | 2 / 2 | 170 MB | 0.65-0.6 | PASS |
| beamer-5 | 5 | typing@60ms | 39 | 3.4 / 3.6 / 3.7 | p95 | 11 | - | - | 0.0 | - | - | 170 MB | 0.6-0.6 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
