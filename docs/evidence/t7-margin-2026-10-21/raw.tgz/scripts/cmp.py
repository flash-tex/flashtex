import json, sys, statistics as st
# cmp.py RUNA RUNB ROW...  -> per row per run: p50/p95 of wall, cpu, instr, IPC, queue, restore, off
def q(v, p):
    v = sorted(x for x in v if x is not None)
    if not v: return None
    i = min(len(v) - 1, max(0, int(round(p * (len(v) - 1)))))
    return v[i]
def load(run, row):
    keys = []; dones = {}
    for l in open(f'{run}/raw/{row}.jsonl'):
        r = json.loads(l)
        if 'key' in r: keys.append(r)
        elif 'done' in r: dones[r['done']['id']] = r['done']
    out = []
    for k in keys:
        d = k['host'] if 'host' in k else dones.get(k['by'], {}); s = d.get('stages', {})
        kc = (s['first_page_mark_kc'] - s['arrival_mark_kc']) if s.get('first_page_mark_kc') and s.get('arrival_mark_kc') else None
        I = s.get('first_page_instr_k')
        fp = s.get('first_page'); cpu = s.get('first_page_cpu')
        out.append(dict(wall=k['edited_page_ms'], cpu=cpu, I=I and I / 1e3, ipc=(I / kc if kc and I else None),
                        q=s.get('queue'), rst=s.get('restore'), off=(fp - cpu if fp is not None and cpu is not None else None),
                        rI=s.get('restore_instr_k') and s['restore_instr_k'] / 1e3))
    return out
for row in sys.argv[3:]:
    print('==', row)
    for run in sys.argv[1:3]:
        try: rs = load(run, row)
        except FileNotFoundError: print('  missing', run); continue
        cols = []
        for f in ('wall', 'cpu', 'I', 'ipc', 'q', 'rst', 'off', 'rI'):
            v = [r[f] for r in rs]
            a, b, m = q(v, .5), q(v, .95), max((x for x in v if x is not None), default=None)
            fmt = lambda x: '-' if x is None else f'{x:.2f}'
            cols.append(f'{f} {fmt(a)}/{fmt(b)}/{fmt(m)}')
        print('  ', run.split('/')[-1], len(rs), ' | '.join(cols))
