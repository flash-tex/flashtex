import json, sys
# usage: keys.py RUNDIR ROW [ROW...]
run = sys.argv[1]
for row in sys.argv[2:]:
    f = f'{run}/raw/{row}.jsonl'
    keys = []; dones = {}; order = []
    for l in open(f):
        r = json.loads(l)
        if 'key' in r: keys.append(r)
        elif 'done' in r:
            dones[r['done']['id']] = r['done']; order.append(r['done']['id'])
    print('==', run, row, len(keys), 'keys')
    for k in keys:
        d = k['host'] if 'host' in k else dones.get(k['by'], {}); s = d.get('stages', {})
        extra = {x: s[x] for x in s if any(t in x for t in ('abandon', 'cancel', 'prep', 'jump', 'wait'))}
        print(k['key'], round(k['edited_page_ms'], 2), 'by', k.get('by'), d.get('status'), 'q', s.get('queue'), s.get('queue_by'),
              'rst', s.get('restore'), 'fp', s.get('first_page'), 'cpu', s.get('first_page_cpu'),
              'off', None if s.get('first_page') is None else round(s['first_page'] - (s.get('first_page_cpu') or 0), 2),
              'fpI', s.get('first_page_instr_k'), 'rI', s.get('restore_instr_k'), 'rp', d.get('restart_page'), 'eI', s.get('edited_instr_k'), 'tI', s.get('typeset_instr_k'), extra)
    if len(sys.argv) > 3 or '-v' in sys.argv: continue
