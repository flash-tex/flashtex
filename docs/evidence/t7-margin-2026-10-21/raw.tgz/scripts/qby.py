import json, sys
# qby.py RUN ROW : keys whose queue wait > 0.3 ms, by part
run, row = sys.argv[1:3]
keys = []; dones = {}
for l in open(f'{run}/raw/{row}.jsonl'):
    r = json.loads(l)
    if 'key' in r: keys.append(r)
    elif 'done' in r: dones[r['done']['id']] = r['done']
for k in keys:
    d = dones.get(k.get('by'), k.get('host', {})); s = d.get('stages', {})
    if s.get('queue', 0) > 0.3:
        print(k['key'], round(k['edited_page_ms'], 2), s.get('queue'), {a: b for a, b in s.get('queue_by', {}).items() if b > 0.05}, s.get('paused_how'))
