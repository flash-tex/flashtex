import json, sys
# ipc.py RUN ROW : IPC (first-page instructions / cycles) per key, sorted, and the keys below 3.0
run, row = sys.argv[1:3]
keys = []; dones = {}
for l in open(f'{run}/raw/{row}.jsonl'):
    r = json.loads(l)
    if 'key' in r: keys.append(r)
    elif 'done' in r: dones[r['done']['id']] = r['done']
v = []
for k in keys:
    d = dones.get(k.get('by'), k.get('host', {})); s = d.get('stages', {})
    if s.get('first_page_mark_kc') and s.get('arrival_mark_kc') and s.get('first_page_instr_k'):
        kc = s['first_page_mark_kc'] - s['arrival_mark_kc']
        v.append((round(s['first_page_instr_k'] / kc, 2), k['key'], round(k['edited_page_ms'], 2)))
ipcs = sorted(x[0] for x in v)
print(row, 'IPC min/p50/max', ipcs[0], ipcs[len(ipcs) // 2], ipcs[-1], 'low keys', [x[1] for x in v if x[0] < 3.0])
