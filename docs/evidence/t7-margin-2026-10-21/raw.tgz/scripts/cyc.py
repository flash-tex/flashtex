import json, sys
# per key: wall, cpu, instr, cycles(arrival->first page), GHz (cycles/cpu), IPC
run = sys.argv[1]
for row in sys.argv[2:]:
    keys = []; dones = {}
    for l in open(f'{run}/raw/{row}.jsonl'):
        r = json.loads(l)
        if 'key' in r: keys.append(r)
        elif 'done' in r: dones[r['done']['id']] = r['done']
    print('==', run, row)
    for k in keys:
        d = k['host'] if 'host' in k else dones.get(k['by'], {}); s = d.get('stages', {})
        fp = s.get('first_page'); cpu = s.get('first_page_cpu'); I = s.get('first_page_instr_k')
        kc = None
        if s.get('first_page_mark_kc') and s.get('arrival_mark_kc'):
            kc = s['first_page_mark_kc'] - s['arrival_mark_kc']
        ghz = round(kc / 1e3 / cpu, 2) if kc and cpu else None
        ipc = round(I / kc, 2) if kc and I else None
        print(k['key'], round(k['edited_page_ms'], 2), d.get('status')[:4], 'cpu', cpu, 'I', I, 'kc', kc, 'GHz/cpu', ghz, 'IPC', ipc,
              'tsI', s.get('typeset_instr_k'), 'tsC', s.get('typeset_cycles_k'))
