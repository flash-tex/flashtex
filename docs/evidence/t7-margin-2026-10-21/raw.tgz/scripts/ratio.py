import json, sys, os, statistics as st
# ratio.py PCRUN MACRUN : per row, median of instruction fields Mac / PC
F = ('first_page_instr_k', 'edited_instr_k', 'typeset_instr_k', 'restore_instr_k', 'paused_instr_k')
def med(run, row):
    keys = []; dones = {}
    for l in open(f'{run}/raw/{row}.jsonl'):
        r = json.loads(l)
        if 'key' in r: keys.append(r)
        elif 'done' in r: dones[r['done']['id']] = r['done']
    out = {}
    for f in F:
        v = []
        for k in keys[1:]:
            d = k['host'] if 'host' in k else dones.get(k.get('by'), {})
            x = d.get('stages', {}).get(f)
            if x: v.append(x / 1e3)
        out[f] = st.median(v) if v else None
    return out
pc, mac = sys.argv[1], sys.argv[2]
for fn in sorted(os.listdir(pc + '/raw')):
    if not fn.endswith('.jsonl') or 'typing' in fn: continue
    row = fn[:-6]
    if not os.path.exists(f'{mac}/raw/{fn}'): continue
    a, b = med(pc, row), med(mac, row)
    print(f'{row:28s}', '  '.join(f'{f.split("_instr")[0]} {a[f]:.1f}/{b[f]:.1f}' for f in F if a[f] and b[f]))
