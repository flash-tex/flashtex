import json, sys, statistics as st
# fld.py RUN ROW FIELD... -> median of each stage field over keys
run, row = sys.argv[1], sys.argv[2]
keys = []; dones = {}
for l in open(f'{run}/raw/{row}.jsonl'):
    r = json.loads(l)
    if 'key' in r: keys.append(r)
    elif 'done' in r: dones[r['done']['id']] = r['done']
out = []
for f in sys.argv[3:]:
    v = []
    for k in keys[1:]:
        d = k['host'] if 'host' in k else dones.get(k['by'], {}); s = d.get('stages', {})
        x = s.get(f, d.get(f))
        if isinstance(x, (int, float)): v.append(x)
    out.append(f'{f}={st.median(v):.3f}' if v else f'{f}=-')
print(row, ' '.join(out))
