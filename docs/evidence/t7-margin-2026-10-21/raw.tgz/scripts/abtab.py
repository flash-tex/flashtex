import json, sys, os
# abtab.py PREFIX ENG_A ENG_B : rows of PREFIX{1,2}-ENG, both rounds pooled (key 0 of each round left out)
pre, A, B = sys.argv[1:4]
D = '/private/tmp/claude-501/-Users-kubar-code-flashtex/440fe00e-c203-4f15-b706-f22dec3a333e/scratchpad/pc'
def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(round(p * (len(v) - 1))))] if v else float('nan')
def load(eng, row):
    out = []
    for r in (1, 2):
        f = f'{D}/{pre}{r}-{eng}/raw/{row}.jsonl'
        if not os.path.exists(f): continue
        keys = []; dones = {}
        for l in open(f):
            x = json.loads(l)
            if 'key' in x: keys.append(x)
            elif 'done' in x: dones[x['done']['id']] = x['done']
        for k in keys[1:]:
            d = dones.get(k.get('by'), k.get('host', {})); s = d.get('stages', {})
            I = s.get('edited_instr_k') or s.get('first_page_instr_k') or 0
            out.append(dict(w=k['edited_page_ms'], I=I / 1e3, fI=(s.get('first_page_instr_k') or 0) / 1e3,
                            cpu=s.get('first_page_cpu') or 0, rst=s.get('restore') or 0,
                            rI=(s.get('restore_instr_k') or 0) / 1e3, ab=s.get('paused_how') == 'abandoned',
                            pz=s.get('paused') or 0, pI=(s.get('paused_instr_k') or 0) / 1e3, q=s.get('queue') or 0))
    return out
rows = sorted({f[:-6] for f in os.listdir(f'{D}/{pre}1-{A}/raw') if f.endswith('.jsonl')})
print(f'| row | engine | n | ms p50 / p95 | first-page instr p50 | to edited page instr p50 | restore instr p50 | thread CPU p50 | abandoned keys: paused ms / instr p50 |')
print('|---|---|---|---|---|---|---|---|---|')
for row in rows:
    for e in (A, B):
        v = load(e, row)
        if not v: continue
        ab = [x for x in v if x['ab']]
        abs_ = f"{q([x['pz'] for x in ab], .5):.2f} / {q([x['pI'] for x in ab], .5):.1f} M" if ab else '-'
        print(f"| {row} | {e} | {len(v)} | {q([x['w'] for x in v], .5):.1f} / {q([x['w'] for x in v], .95):.1f} | {q([x['fI'] for x in v], .5):.1f} M | {q([x['I'] for x in v], .5):.1f} M | {q([x['rI'] for x in v], .5):.2f} M | {q([x['cpu'] for x in v], .5):.2f} | {abs_} |")
