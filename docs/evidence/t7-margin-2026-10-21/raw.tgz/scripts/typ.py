import json, sys, statistics as st
# typ.py RUNA RUNB ROW... : typing rows split by how the key's compile began (abandoned / idle)
def q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(round(p * (len(v) - 1))))] if v else float('nan')
for row in sys.argv[3:]:
    for run in sys.argv[1:3]:
        keys = []; dones = {}
        for l in open(f'{run}/raw/{row}.jsonl'):
            r = json.loads(l)
            if 'key' in r: keys.append(r)
            elif 'done' in r: dones[r['done']['id']] = r['done']
        g = {}
        for k in keys:
            d = dones.get(k.get('by'), k.get('host', {})); s = d.get('stages', {})
            how = s.get('paused_how', 'idle')
            g.setdefault(how, []).append((k['edited_page_ms'], s.get('queue', 0), s.get('paused', 0), s.get('paused_instr_k', 0) / 1e3, s.get('first_page_cpu') or 0, (s.get('first_page_instr_k') or 0) / 1e3))
        line = []
        for how, v in sorted(g.items()):
            f = lambda i, p: q([x[i] for x in v], p)
            line.append(f'{how} n={len(v)} wall {f(0,.5):.2f}/{f(0,.95):.2f} q {f(1,.5):.2f}/{f(1,.95):.2f} paused {f(2,.5):.2f} ({f(3,.5):.1f}M) cpu {f(4,.5):.2f} I {f(5,.5):.1f}M')
        print(row, run.split('/')[-1], ' | '.join(line))
