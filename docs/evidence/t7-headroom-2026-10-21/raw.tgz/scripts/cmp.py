import json, sys
# cmp.py RUN_A RUN_B: per row, means over keys > 0 of stages both runs have (ms), and the
# deleted letters' length setting (us)
rowsets = ['full-1000-split@middle', 'full-1000-letter@start', 'beamer-30-letter@end',
           'beamer-30-letter@start', 'full-10-letter@start']
def load(run, r):
    rows = [json.loads(l) for l in open(f'{run}/raw/{r}.jsonl')]
    return [x for x in rows if 'key' in x and x['key'] > 0]
mean = lambda v: sum(v) / len(v) if v else float('nan')
print('row | run | ms p50 | apply | setlen (deletes) | move_spans | find | restore | rest to the edited page')
for r in rowsets:
    for run in sys.argv[1:]:
        k = load(run, r)
        st = [x['host']['stages'] for x in k]
        ms = sorted(x['edited_page_ms'] for x in k)
        dl = [s['apply_us'][2] for s in st if s.get('apply_us') and s['apply_us'][2] > 0]
        g = lambda n: mean([s.get(n) or 0 for s in st])
        rest = mean([x['edited_page_ms'] - (x['host']['stages'].get('apply') or 0) - (x['host']['stages'].get('move_spans') or 0)
                     - (x['host']['stages'].get('find') or 0) - (x['host']['stages'].get('restore') or 0) for x in k])
        print(f"{r} | {run.split('/')[-1]} | {ms[len(ms)//2]:.2f} | {g('apply'):.2f} | {mean(dl):.0f} (n {len(dl)}, max {max(dl) if dl else 0}) | {g('move_spans'):.2f} | {g('find'):.2f} | {g('restore'):.2f} | {rest:.2f}")
