import collections, sys, re
# chain.py MARKS CHAIN [FROM TO] [LEAFRE]: samples in FROM..TO windows (marks letters, default a..b):
# by leaf matching LEAFRE (default all), the first 4 flashtex frames of the chain
marks = [l.split() for l in open(sys.argv[1]) if l.strip()]
marks = [(c, int(t) / 1e9) for c, t in marks]
fr_, to_ = (sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else ('a', 'b')
leafre = re.compile(sys.argv[5]) if len(sys.argv) > 5 else None
wins = []
for i, (c, t) in enumerate(marks):
    if c == fr_:
        b = next((u for d, u in marks[i + 1:] if d == to_), None)
        if b:
            wins.append((t, b))
inwin = lambda t: any(a <= t < b for a, b in wins)
cnt = collections.Counter()
tot = 0
cur = None
fr = []


def short(s):
    s = re.sub(r'\+0x[0-9a-f]+$', '', s)
    s = s.replace('flashtex_engine::', '').replace('flashtex_runtime::', '')
    return s[:60]


def flush():
    global tot
    if cur is None or not inwin(cur):
        return
    tot += 1
    if not fr:
        return
    if leafre and not leafre.search(fr[0]):
        return
    own = [short(f) for f in fr if ('flashtex' in f or 'G::' in f)][:4]
    cnt[(short(fr[0]), ' < '.join(own))] += 1


for l in open(sys.argv[2]):
    if l.strip() and not l.startswith((' ', '\t')):
        flush()
        p = l.split()
        try:
            cur = float(p[0].rstrip(':'))
        except ValueError:
            cur = None
        fr = []
    elif l.strip() and cur is not None:
        s = l.strip().split(None, 1)
        fr.append(s[1] if len(s) > 1 else '?')
flush()
print('windows', len(wins), 'samples', tot)
for k, v in cnt.most_common(40):
    print(f'{v:5} {100*v/max(tot,1):5.1f}%  {k[0]}  <<  {k[1]}')
