import json, sys, glob
# per row: mean over keys>0 of each phase's wall/user/sys/off (us), and restore steps, apply steps
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    if not rows or not rows[0]['host']['stages'].get('marks'):
        continue
    acc = {}
    order = []
    for r in rows:
        for m, w, u, y in r['host']['stages']['marks']:
            y = y or 0
            if m not in acc:
                acc[m] = [0, 0, 0, 0, 0]
                order.append(m)
            a = acc[m]
            a[0] += w; a[1] += u; a[2] += y; a[3] += max(0, w - u - y); a[4] += 1
    rs = [0] * 5
    for r in rows:
        for i, v in enumerate(r['host']['stages'].get('restore_us') or [0] * 5):
            rs[i] += v
    n = len(rows)
    ms = sorted(r['edited_page_ms'] for r in rows)
    print(f"{f.split('/')[-1]:32} p50 {ms[n//2]:.2f} | " + ' '.join(f"{m}:{a[0]//a[4]}/{a[1]//a[4]}/{a[2]//a[4]}/{a[3]//a[4]}" for m, a in ((m, acc[m]) for m in order)) + f" | rs {[v//n for v in rs]}")
