import json, sys
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r]
    print('==', f.split('/')[-1])
    print('key  tot  | q    apply find key  chg  rest test | ewall ecpu  dl   fsend| restI  edI   tsI  fpsys rsys apus')
    for r in rows:
        s = r['host']['stages']
        g = lambda k: s.get(k) or 0
        h = r['host']
        print(f"{r['key']:3} {r['edited_page_ms']:5.2f} | {g('queue'):.2f} {g('apply'):.2f}  {g('find'):.2f} {g('key'):.2f} {g('changes'):.2f} {g('restore'):.2f} {g('test'):.2f} | {g('edited_wall'):.2f} {g('edited_cpu'):.2f} {g('first_page_dl'):.2f} {g('first_page_send'):.2f} | {g('restore_instr_k')/1e3:5.1f} {g('edited_instr_k')/1e3:5.1f} {g('typeset_instr_k')/1e3:5.1f} {g('first_page_sys'):4} {g('restore_sys'):3} {s.get('apply_us')} {r.get('kind')} p{r.get('edited_page')} rs{h.get('restart_page')}{'M' if h.get('restart_midline') else ''}")
