import json, sys
# top keys of each row: ms, apply setlen, restore, phases
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    rows.sort(key=lambda r: -r['edited_page_ms'])
    ms = sorted(r['edited_page_ms'] for r in rows)
    n = len(ms)
    p95 = ms[min(n - 1, int(round(0.95 * (n - 1))))]
    print(f"== {f.split('/')[-1]} n={n} p50 {ms[n//2]:.2f} p95~{p95:.2f}")
    for r in rows[:4]:
        s = r['host']['stages']
        ph = ' '.join(f"{m}:{w}" for m, w, u, y in (s.get('marks') or []))
        print(f"  k{r['key']:2} {r['edited_page_ms']:5.2f} setlen {(s.get('apply_us') or [0,0,0])[2]:4} rs {s.get('restore')} | {ph}")
