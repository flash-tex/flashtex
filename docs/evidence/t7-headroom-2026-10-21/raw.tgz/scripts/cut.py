import json, sys, collections
# delete keys by cut_mode: setlen us, apply ms, restore ms, total ms
agg = collections.defaultdict(list)
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    per = collections.defaultdict(list)
    for r in rows:
        s = r['host']['stages']
        au = s.get('apply_us') or [0] * 5
        shrink = au[2] > 0
        m = s.get('cut_mode')
        key = (m, 'del' if shrink else 'ins')
        ph = {x[0]: x for x in (s.get('marks') or [])}
        p = ph.get('p', [0, 0, 0, 0])
        per[key].append((r['edited_page_ms'], au[2], s['apply'], s.get('restore') or 0, p[1], p[3] or 0))
        agg[key].append((r['edited_page_ms'], au[2], s['apply'], s.get('restore') or 0, p[1], p[3] or 0))
    print('==', f.split('/')[-1])
    for k in sorted(per, key=str):
        v = per[k]
        mean = lambda i: sum(x[i] for x in v) / len(v)
        print(f"  mode {k[0]} {k[1]} n={len(v):2} ms {mean(0):5.2f} max {max(x[0] for x in v):5.2f} setlen {mean(1):5.0f}us apply {mean(2):.2f} restore {mean(3):.2f} p-wall {mean(4):.0f} p-sys {mean(5):.0f}")
print('== all')
for k in sorted(agg, key=str):
    v = agg[k]
    mean = lambda i: sum(x[i] for x in v) / len(v)
    print(f"  mode {k[0]} {k[1]} n={len(v):3} ms {mean(0):5.2f} setlen {mean(1):5.0f}us apply {mean(2):.2f} restore {mean(3):.2f} p-wall {mean(4):.0f} p-sys {mean(5):.0f}")
