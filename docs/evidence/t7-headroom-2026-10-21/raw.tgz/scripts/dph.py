import json, sys, collections
# per row: by cut_mode and del/ins, the mean of each phase's off-CPU and sys (us)
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    per = collections.defaultdict(lambda: collections.defaultdict(list))
    for r in rows:
        s = r['host']['stages']
        au = s.get('apply_us') or [0] * 5
        key = (s.get('cut_mode'), 'del' if au[2] > 0 else 'ins')
        for m, w, u, y in s.get('marks') or []:
            y = y or 0
            per[key][m].append((w, y, max(0, w - u - y)))
        per[key]['tot'].append((r['edited_page_ms'] * 1000, 0, 0))
    print('==', f.split('/')[-1])
    for k in sorted(per, key=str):
        d = per[k]
        out = []
        for m in ['tot', 'p', 'r', 'd']:
            v = d.get(m, [])
            if v:
                out.append(f"{m}:{sum(x[0] for x in v)//len(v)}/{sum(x[1] for x in v)//len(v)}/{sum(x[2] for x in v)//len(v)}")
        print(f"  mode {k[0]} {k[1]} n={len(d['tot'])} wall/sys/off " + ' '.join(out))
