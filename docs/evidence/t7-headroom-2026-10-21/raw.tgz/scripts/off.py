import json, sys
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r]
    print('==', f.split('/')[-1])
    for r in rows:
        s = r['host']['stages']
        g = lambda k: s.get(k) or 0
        fp, fpc = g('first_page'), g('first_page_cpu')
        pre = g('queue') + g('apply') + g('move_spans')
        print(f"{r['key']:3} tot {r['edited_page_ms']:5.2f} fp {fp:5.2f} cpu {fpc:5.2f} off {fp-fpc:4.2f} pre {pre:4.2f} | ew {g('edited_wall'):5.2f} ec {g('edited_cpu'):5.2f} eoff {g('edited_wall')-g('edited_cpu'):4.2f} | instr {g('first_page_instr_k')/1e3:5.1f}M cyc? sys {g('first_page_sys')} flt {g('first_page_flt')} rest {g('restore'):.2f}")
