import json, sys, statistics as st
# per row: keys split by flushed_prev; per group the means of apply, setlen, restore, phases
def phases(s):
    d = {}
    for m, w, u, y in s.get('marks') or []:
        d[m] = (w, u, y if y is not None else 0)
    return d
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    print('==', f.split('/')[-1])
    for r in rows:
        s = r['host']['stages']
        fl = s.get('flush') or [None, None, None]
        ph = phases(s)
        g = lambda k: s.get(k) or 0
        txt = ' '.join(f"{m}:{w}/{u}/{y}" for m, (w, u, y) in ph.items())
        print(f"{r['key']:3} {r['edited_page_ms']:5.2f} F{int(bool(fl[0]))} pend{fl[1]} fus{fl[2]} ap{g('apply'):.2f} {s.get('apply_us')} rs{g('restore'):.2f} {s.get('restore_us')} | {txt}")
    for flag in (False, True):
        sel = [r for r in rows if bool((r['host']['stages'].get('flush') or [False])[0]) == flag]
        if not sel:
            continue
        ms = [r['edited_page_ms'] for r in sel]
        dl = [r for r in sel if (r['host']['stages'].get('apply_us') or [0, 0, 0])[2] > 0]
        ins = [r for r in sel if (r['host']['stages'].get('apply_us') or [0, 0, 0])[2] == 0]
        mean = lambda v: sum(v) / len(v) if v else float('nan')
        print(f"  flushed={flag}: n={len(sel)} ms mean {mean(ms):.2f} max {max(ms):.2f}; deletes n={len(dl)} setlen {mean([r['host']['stages']['apply_us'][2] for r in dl]):.0f}us ms {mean([r['edited_page_ms'] for r in dl]):.2f}; inserts ms {mean([r['edited_page_ms'] for r in ins]):.2f}; restore {mean([r['host']['stages']['restore'] for r in sel]):.2f}")
