import json, sys
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r and r['key'] > 0]
    t = sorted(r['host']['stages'].get('restore_us', [0, 0])[1] for r in rows)
    io = [r['host']['stages'].get('io_us') for r in rows[:1]]
    print(f.split('/')[-3], f.split('/')[-1][:24], t, io)
