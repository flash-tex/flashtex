Reference run.

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@end | 19 | 7.8 / 8.8 / 9.4 | p95 | 11 | 5.8 | 36.8 | 0.7 | 19/19 | 3 / 3 | 829 MB | 3.46-2.92 | PASS |
| full-1000 | 1002 | split@middle | 19 | 8.7 / 10.6 / 10.7 | p95 | 11 | 10.6 | 217.0 | 0.7 | 19/19 | 33 / 33 | 829 MB | 2.92-2.76 | PASS |
| full-1000 | 1002 | letter@start | 19 | 8.8 / 10.1 / 10.1 | p95 | 11 | 10.1 | 48.7 | 0.7 | 19/19 | 2 / 2 | 829 MB | 2.76-2.54 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.0 / 10.3 / 10.5 | p95 | 11 | 10.3 | 42.1 | 0.7 | 19/19 | 2 / 2 | 234 MB | 2.54-2.22 | PASS |
| beamer-30 | 58 | letter@end | 19 | 8.3 / 10.0 / 10.2 | p95 | 11 | 10.0 | 38.8 | 0.7 | 19/19 | 2 / 2 | 234 MB | 2.22-1.96 | PASS |
| beamer-30 | 58 | split@middle | 19 | 9.2 / 10.4 / 31.8 | p95 | 11 | 10.4 | 83.7 | 0.8 | 19/19 | 3 / 3 | 234 MB | 1.96-1.88 | PASS |
| full-10 | 11 | split@middle | 19 | 7.9 / 9.0 / 9.3 | p95 | 11 | 5.3 | 31.6 | 0.8 | 19/19 | 3 / 3 | 177 MB | 1.88-1.59 | PASS |
| full-10 | 11 | letter@start | 19 | 9.0 / 10.1 / 10.1 | p95 | 11 | 10.1 | 30.4 | 1.2 | 19/19 | 2 / 2 | 177 MB | 1.59-1.55 | PASS |
| full-10 | 11 | letter@end | 19 | 7.6 / 9.1 / 9.2 | p95 | 11 | 5.1 | 21.9 | 0.8 | 19/19 | 3 / 3 | 177 MB | 1.55-1.5 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
