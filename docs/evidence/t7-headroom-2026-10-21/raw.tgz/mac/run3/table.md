**NON-REFERENCE run**: on battery at start (62 %); on battery at end (62 %)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@end | 19 | 7.5 / 8.5 / 8.8 | p95 | 11 | 5.5 | 36.9 | 0.6 | 19/19 | 3 / 3 | 809 MB | 3.3-2.98 | PASS |
| full-1000 | 1002 | split@middle | 19 | 8.5 / 10.5 / 12.9 | p95 | 11 | 10.5 | 238.6 | 0.5 | 19/19 | 33 / 33 | 809 MB | 2.98-2.67 | PASS |
| full-1000 | 1002 | letter@start | 19 | 8.6 / 9.8 / 10.0 | p95 | 11 | 9.8 | 50.1 | 0.8 | 19/19 | 2 / 2 | 809 MB | 2.67-2.26 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.5 / 11.1 / 11.1 | p95 | 11 | 11.1 | 44.4 | 1.7 | 19/19 | 2 / 2 | 235 MB | 2.26-2.13 | MISS: p95 11.1 ms > 11 ms |
| beamer-30 | 58 | letter@end | 19 | 8.9 / 9.8 / 9.9 | p95 | 11 | 9.8 | 39.9 | 1.4 | 19/19 | 2 / 2 | 235 MB | 2.13-2.12 | PASS |
| beamer-30 | 58 | split@middle | 19 | 8.3 / 10.6 / 26.3 | p95 | 11 | 10.6 | 76.1 | 1.3 | 19/19 | 3 / 3 | 235 MB | 2.12-2.03 | PASS |
| full-10 | 11 | split@middle | 19 | 7.8 / 9.7 / 19.9 | p95 | 11 | 4.6 | 39.2 | 0.6 | 19/19 | 3 / 3 | 176 MB | 1.87-1.88 | PASS |
| full-10 | 11 | letter@start | 19 | 8.6 / 9.3 / 9.3 | p95 | 11 | 9.3 | 32.8 | 1.1 | 19/19 | 2 / 2 | 176 MB | 1.88-1.73 | PASS |
| full-10 | 11 | letter@end | 19 | 7.3 / 8.9 / 9.5 | p95 | 11 | 5.0 | 22.2 | 0.7 | 19/19 | 3 / 3 | 176 MB | 1.73-1.76 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
