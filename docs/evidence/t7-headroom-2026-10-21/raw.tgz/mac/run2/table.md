**NON-REFERENCE run**: on battery at start (77 %); on battery at end (77 %)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@end | 19 | 7.3 / 11.4 / 14.2 | p95 | 11 | 8.3 | 38.0 | 4.0 | 19/19 | 3 / 3 | 830 MB | 2.61-3.4 | MISS: p95 11.4 ms > 11 ms |
| full-1000 | 1002 | split@middle | 19 | 8.3 / 9.8 / 9.8 | p95 | 11 | 9.8 | 206.5 | 0.8 | 19/19 | 33 / 33 | 830 MB | 3.4-2.96 | PASS |
| full-1000 | 1002 | letter@start | 19 | 7.7 / 9.6 / 9.9 | p95 | 11 | 9.6 | 50.0 | 0.8 | 19/19 | 2 / 2 | 830 MB | 2.96-2.72 | PASS |
| beamer-30 | 58 | letter@start | 19 | 8.4 / 10.1 / 15.2 | p95 | 11 | 10.1 | 41.9 | 1.1 | 19/19 | 2 / 2 | 234 MB | 2.5-2.46 | PASS |
| beamer-30 | 58 | letter@end | 19 | 8.3 / 9.8 / 15.4 | p95 | 11 | 9.8 | 42.5 | 0.5 | 19/19 | 2 / 2 | 234 MB | 2.46-2.31 | PASS |
| beamer-30 | 58 | split@middle | 19 | 8.2 / 9.6 / 25.8 | p95 | 11 | 9.6 | 74.1 | 0.6 | 19/19 | 3 / 3 | 234 MB | 2.31-2.12 | PASS |
| full-10 | 11 | split@middle | 19 | 7.0 / 8.3 / 8.5 | p95 | 11 | 4.5 | 30.7 | 0.5 | 19/19 | 3 / 3 | 175 MB | 2.11-2.03 | PASS |
| full-10 | 11 | letter@start | 19 | 8.5 / 10.9 / 10.9 | p95 | 11 | 10.9 | 34.0 | 1.2 | 19/19 | 2 / 2 | 175 MB | 2.03-1.86 | PASS |
| full-10 | 11 | letter@end | 19 | 7.1 / 8.6 / 8.9 | p95 | 11 | 4.9 | 22.2 | 0.6 | 19/19 | 3 / 3 | 175 MB | 1.86-1.81 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
