**NON-REFERENCE run**: on battery at start (61 %); on battery at end (61 %)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@end | 19 | 6.9 / 8.0 / 8.6 | p95 | 11 | 4.9 | 37.3 | 0.2 | 19/19 | 3 / 3 | 827 MB | 2.29-2.15 | PASS |
| full-1000 | 1002 | split@middle | 19 | 7.7 / 8.7 / 9.6 | p95 | 11 | 8.7 | 254.9 | 0.2 | 19/19 | 33 / 33 | 827 MB | 2.15-2.21 | PASS |
| full-1000 | 1002 | letter@start | 19 | 7.6 / 8.8 / 10.4 | p95 | 11 | 8.8 | 55.0 | 0.2 | 19/19 | 2 / 2 | 827 MB | 2.21-2.11 | PASS |
| beamer-30 | 58 | letter@start | 19 | 9.4 / 10.4 / 11.6 | p95 | 11 | 10.4 | 45.5 | 1.4 | 19/19 | 2 / 2 | 238 MB | 2.11-1.94 | PASS |
| beamer-30 | 58 | letter@end | 19 | 8.4 / 10.1 / 12.4 | p95 | 11 | 10.1 | 46.3 | 1.4 | 19/19 | 2 / 2 | 238 MB | 1.94-1.95 | PASS |
| beamer-30 | 58 | split@middle | 19 | 8.8 / 10.5 / 28.2 | p95 | 11 | 10.5 | 79.1 | 1.0 | 19/19 | 3 / 3 | 238 MB | 1.95-1.87 | PASS |
| full-10 | 11 | split@middle | 19 | 7.5 / 8.5 / 10.2 | p95 | 11 | 4.7 | 38.8 | 0.2 | 19/19 | 3 / 3 | 176 MB | 1.96-1.88 | PASS |
| full-10 | 11 | letter@start | 19 | 8.9 / 9.5 / 10.7 | p95 | 11 | 9.5 | 34.7 | 0.7 | 19/19 | 2 / 2 | 176 MB | 1.88-2.05 | PASS |
| full-10 | 11 | letter@end | 19 | 7.8 / 8.4 / 8.4 | p95 | 11 | 4.5 | 24.6 | 0.2 | 19/19 | 3 / 3 | 176 MB | 2.05-2.19 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
