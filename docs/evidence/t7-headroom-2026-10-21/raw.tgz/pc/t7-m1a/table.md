**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex.slice throttled 397 of 842 periods (116.1 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@start | 11 | 10.4 / 13.4 / 13.4 | max | 11 | 13.4 | 88.6 | 0.1 | 11/11 | 2 / 2 | 688 MB | 7.34-7.03 | MISS: max 13.4 ms > 11 ms |
| full-1000 | 1002 | letter@end | 11 | 9.7 / 11.6 / 11.6 | max | 11 | 6.8 | 50.3 | 0.0 | 11/11 | 3 / 3 | 688 MB | 7.03-6.63 | MISS: max 11.6 ms > 11 ms |
| full-1000 | 1002 | split@middle | 11 | 9.6 / 11.2 / 11.2 | max | 11 | 11.2 | 324.8 | 0.1 | 11/11 | 33 / 33 | 688 MB | 6.63-6.15 | MISS: max 11.2 ms > 11 ms |
| beamer-30 | 58 | letter@end | 11 | 10.5 / 11.7 / 11.7 | max | 11 | 11.7 | 58.2 | 0.1 | 11/11 | 2 / 2 | 214 MB | 6.15-5.81 | MISS: max 11.7 ms > 11 ms |
| beamer-30 | 58 | split@middle | 11 | 10.7 / 41.1 / 41.1 | max | 11 | 41.1 | 168.2 | 30.0 | 11/11 | 3 / 3 | 214 MB | 5.81-5.99 | MISS: max 41.1 ms > 11 ms |
| beamer-30 | 58 | letter@start | 11 | 12.9 / 16.3 / 16.3 | max | 11 | 16.3 | 112.7 | 0.1 | 11/11 | 2 / 2 | 214 MB | 5.99-6.07 | MISS: max 16.3 ms > 11 ms |
| full-10 | 11 | letter@end | 11 | 11.7 / 44.2 / 44.2 | max | 11 | 5.6 | 69.8 | 0.2 | 11/11 | 3 / 3 | 161 MB | 6.07-6.14 | MISS: max 44.2 ms > 11 ms |
| full-10 | 11 | split@middle | 11 | 10.0 / 50.3 / 50.3 | max | 11 | 6.2 | 102.9 | 0.1 | 11/11 | 3 / 3 | 161 MB | 6.14-6.37 | MISS: max 50.3 ms > 11 ms |
| full-10 | 11 | letter@start | 11 | 11.4 / 45.2 / 45.2 | max | 11 | 45.2 | 101.4 | 34.0 | 11/11 | 2 / 2 | 161 MB | 6.37-6.5 | MISS: max 45.2 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
