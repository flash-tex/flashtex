**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex.slice throttled 55 of 763 periods (2.8 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@start | 11 | 11.1 / 11.8 / 11.8 | max | 11 | 11.8 | 87.3 | 0.1 | 11/11 | 2 / 2 | 686 MB | 2.98-3.61 | MISS: max 11.8 ms > 11 ms |
| full-1000 | 1002 | letter@end | 11 | 10.5 / 11.3 / 11.3 | max | 11 | 6.4 | 52.6 | 0.0 | 11/11 | 3 / 3 | 686 MB | 3.61-3.65 | MISS: max 11.3 ms > 11 ms |
| full-1000 | 1002 | split@middle | 11 | 11.1 / 12.0 / 12.0 | max | 11 | 12.0 | 344.0 | 0.1 | 11/11 | 33 / 33 | 686 MB | 3.65-3.85 | MISS: max 12.0 ms > 11 ms |
| beamer-30 | 58 | letter@end | 11 | 10.4 / 11.4 / 11.4 | max | 11 | 11.4 | 57.5 | 0.1 | 11/11 | 2 / 2 | 215 MB | 3.85-3.86 | MISS: max 11.4 ms > 11 ms |
| beamer-30 | 58 | split@middle | 11 | 10.8 / 40.2 / 40.2 | max | 11 | 40.2 | 122.3 | 0.1 | 11/11 | 3 / 3 | 215 MB | 3.86-3.87 | MISS: max 40.2 ms > 11 ms |
| beamer-30 | 58 | letter@start | 11 | 10.8 / 12.7 / 12.7 | max | 11 | 12.7 | 57.2 | 0.1 | 11/11 | 2 / 2 | 215 MB | 3.87-3.88 | MISS: max 12.7 ms > 11 ms |
| full-10 | 11 | letter@end | 11 | 9.8 / 11.2 / 11.2 | max | 11 | 4.8 | 32.2 | 0.0 | 11/11 | 3 / 3 | 161 MB | 3.88-3.81 | MISS: max 11.2 ms > 11 ms |
| full-10 | 11 | split@middle | 11 | 9.7 / 10.2 / 10.2 | max | 11 | 4.2 | 44.4 | 0.0 | 11/11 | 3 / 3 | 161 MB | 3.81-3.75 | PASS |
| full-10 | 11 | letter@start | 11 | 9.7 / 10.3 / 10.3 | max | 11 | 10.3 | 44.6 | 0.2 | 11/11 | 2 / 2 | 161 MB | 3.75-3.61 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
