**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex.slice throttled 153 of 762 periods (0.5 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@start | 11 | 11.4 / 14.0 / 14.0 | max | 11 | 14.0 | 89.1 | 0.1 | 11/11 | 2 / 2 | 690 MB | 5.2-5.1 | MISS: max 14.0 ms > 11 ms |
| full-1000 | 1002 | letter@end | 11 | 9.8 / 12.0 / 12.0 | max | 11 | 7.1 | 55.0 | 0.1 | 11/11 | 3 / 3 | 690 MB | 5.1-5.01 | MISS: max 12.0 ms > 11 ms |
| full-1000 | 1002 | split@middle | 11 | 9.7 / 10.5 / 10.5 | max | 11 | 10.5 | 332.9 | 0.1 | 11/11 | 33 / 33 | 690 MB | 5.01-5.01 | PASS |
| beamer-30 | 58 | letter@end | 11 | 10.6 / 13.1 / 13.1 | max | 11 | 13.1 | 84.0 | 0.7 | 11/11 | 2 / 2 | 220 MB | 5.01-4.93 | MISS: max 13.1 ms > 11 ms |
| beamer-30 | 58 | split@middle | 11 | 10.7 / 40.4 / 40.4 | max | 11 | 40.4 | 125.9 | 0.2 | 11/11 | 3 / 3 | 220 MB | 4.93-4.85 | MISS: max 40.4 ms > 11 ms |
| beamer-30 | 58 | letter@start | 11 | 11.0 / 12.2 / 12.2 | max | 11 | 12.2 | 59.1 | 0.1 | 11/11 | 2 / 2 | 220 MB | 4.85-4.79 | MISS: max 12.2 ms > 11 ms |
| full-10 | 11 | letter@end | 11 | 9.7 / 10.4 / 10.4 | max | 11 | 4.5 | 32.5 | 0.0 | 11/11 | 3 / 3 | 165 MB | 4.79-4.64 | PASS |
| full-10 | 11 | split@middle | 11 | 10.0 / 11.1 / 11.1 | max | 11 | 5.2 | 45.5 | 0.1 | 11/11 | 3 / 3 | 165 MB | 4.64-4.59 | MISS: max 11.1 ms > 11 ms |
| full-10 | 11 | letter@start | 11 | 9.8 / 14.5 / 14.5 | max | 11 | 14.5 | 45.1 | 0.1 | 11/11 | 2 / 2 | 165 MB | 4.59-4.62 | MISS: max 14.5 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
