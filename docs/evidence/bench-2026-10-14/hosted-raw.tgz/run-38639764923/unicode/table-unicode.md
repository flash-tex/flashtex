## unicode

| document | n | flashtex-v3 build p50 / p95 | xelatex one pass p50 / p95 | latexmk -xelatex p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk |
|---|---:|---:|---:|---:|---:|---:|---|
| b01 | 9 | 608 ms / 811 ms | 954 ms / 1.10 s | 1.50 s / 1.68 s (2) | 1.57× | 2.47× | structurally equal (xetex-pdfparity) |
| b02 | 9 | 1.21 s / 1.28 s | 1.19 s / 1.41 s | 1.92 s / 2.10 s (2) | 0.99× | 1.59× | structurally equal (xetex-pdfparity) |
| b03 | 9 | 2.98 s / 3.12 s | 1.71 s / 2.02 s | 3.05 s / 3.32 s (2) | 0.57× | 1.02× | structurally equal (xetex-pdfparity) |
| b04 | 9 | 1.86 s / 2.11 s | 1.17 s / 1.35 s | 2.64 s / 2.78 s (3) | 0.63× | 1.42× | structurally equal (xetex-pdfparity) |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | xelatex | latexmk | v3 passes (--progress) |
|---|---:|---:|---:|---|
| b01 | 220 MB | 210 MB | 194 MB | flashtex-v3: wrote v3-out.pdf (380 ms) |
| b02 | 223 MB | 212 MB | 194 MB | flashtex-v3: wrote v3-out.pdf (1433 ms) |
| b03 | 226 MB | 212 MB | 198 MB | flashtex-v3: wrote v3-out.pdf (2662 ms) |
| b04 | 220 MB | 203 MB | 196 MB | flashtex-v3: wrote v3-out.pdf (1587 ms) |
unicode-keys-b01-article.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 7.2, "edited_ms": 7.2, "done_ms": 11.9, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 130.1, "peak_mb": 204.1, "sources": 1}

unicode-keys-b02-georgia.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 8.1, "edited_ms": 8.1, "done_ms": 17.1, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 130.3, "peak_mb": 205.2, "sources": 1}

unicode-keys-b03-unicode-math.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 10.7, "edited_ms": 10.7, "done_ms": 15.7, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 143.3, "peak_mb": 213.2, "sources": 1}

unicode-keys-b04-fontspec-11pages.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 11, "first_ms": 3.9, "edited_ms": 13.9, "done_ms": 31.9, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["page"], "footprint_mb": 138.6, "peak_mb": 214.4, "sources": 11}

```
shard unicode, commit eb9edd97588f4a4de1a47a09ff6b808bd0105a31, 2026-10-14T21:52:15Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 18.67 20.19 13.75 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    21%    427k  436M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
eb9edd97588f4a4de1a47a09ff6b808bd0105a31
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 14.00 11.76 11.55 }
```
