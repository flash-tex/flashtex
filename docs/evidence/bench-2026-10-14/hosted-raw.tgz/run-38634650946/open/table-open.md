## open

| document | kind | n | pages | first page p50 / p95 | all pages p50 / p95 | DONE p50 / p95 | passes | host peak RSS |
|---|---|---:|---:|---:|---:|---:|---|---:|
| open-beamer | open | 7 | 58 | 670 ms / 833 ms | 2.75 s / 3.17 s | 4.83 s / 6.72 s | [2] | 127 MB |
| open-full | open | 7 | 1002 | 285 ms / 483 ms | 10.34 s / 19.73 s | 31.60 s / 56.22 s | [3] | 672 MB |
| open | open | 14 | 3 | 149 ms / 2.32 s | 158 ms / 87.77 s | 247 ms / 132.91 s | [2, 3] | 614 MB |
| open-infdesc | open | 7 | 1140 | 1.58 s / 2.64 s | 137.56 s / 146.40 s | 208.78 s / 224.84 s | [3] | 1087 MB |
| open-plain | open | 14 | 100 | 61 ms / 70 ms | 453 ms / 4.54 s | 773 ms / 7.80 s | [2] | 487 MB |
| reopen-beamer | reopen | 7 | 58 | 578 ms / 686 ms | 2.43 s / 2.52 s | 2.47 s / 2.57 s | [1] | 115 MB |
| reopen-full | reopen | 7 | 1002 | 470 ms / 655 ms | 15.04 s / 17.35 s | 15.12 s / 17.41 s | [1] | 544 MB |
| reopen | reopen | 14 | 3 | 138 ms / 2.01 s | 149 ms / 44.19 s | 179 ms / 44.38 s | [1] | 449 MB |
| reopen-infdesc | reopen | 7 | 1140 | 1.65 s / 1.87 s | 67.92 s / 78.24 s | 68.14 s / 78.63 s | [1] | 906 MB |
| reopen-plain | reopen | 14 | 100 | 63 ms / 95 ms | 452 ms / 4.52 s | 476 ms / 4.54 s | [1] | 478 MB |
```
shard open, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T21:09:33Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 35.83 16.15 6.47 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 1.76 1.85 1.99 }
```
