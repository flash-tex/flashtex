## modes

```
{"summary": true, "doc": "plain-1000", "engine": "ref", "tag": "mode-ref-low-memory", "pages_typed": "0,300,600,999", "profile": "low-memory", "keys": 37, "peak_rss": 508133376, "peak_rss_sampled": 508133376, "peak_rss_kernel": 230394176, "killed_at_limit": false, "edited_p50": 15.455396, "edited_p9
{"summary": true, "doc": "full-1000", "engine": "ref", "tag": "mode-ref-low-memory", "pages_typed": "0,300,600,999", "profile": "low-memory", "keys": 37, "peak_rss": 569589760, "peak_rss_sampled": 569589760, "peak_rss_kernel": 246909248, "killed_at_limit": false, "edited_p50": 23.430208, "edited_p95
{"summary": true, "doc": "infdesc-x2", "engine": "ref", "tag": "mode-ref-low-memory", "pages_typed": "110,270", "profile": "low-memory", "keys": 3, "peak_rss": 466698240, "peak_rss_sampled": 466698240, "peak_rss_kernel": 274172160, "killed_at_limit": false, "edited_p50": null, "edited_p95": null, "s
{"summary": true, "doc": "plain-1000", "engine": "ref", "tag": "mode-ref-balanced", "pages_typed": "0,300,600,999", "profile": "balanced", "keys": 37, "peak_rss": 596426752, "peak_rss_sampled": 596426752, "peak_rss_kernel": 507317632, "killed_at_limit": false, "edited_p50": 11.5840005, "edited_p95":
{"summary": true, "doc": "full-1000", "engine": "ref", "tag": "mode-ref-balanced", "pages_typed": "0,300,600,999", "profile": "balanced", "keys": 37, "peak_rss": 698941440, "peak_rss_sampled": 698941440, "peak_rss_kernel": 593481216, "killed_at_limit": false, "edited_p50": 18.7942915, "edited_p95": 
{"summary": true, "doc": "infdesc-x2", "engine": "ref", "tag": "mode-ref-balanced", "pages_typed": "110,270", "profile": "balanced", "keys": 3, "peak_rss": 1173782528, "peak_rss_sampled": 1173782528, "peak_rss_kernel": 1121833728, "killed_at_limit": false, "edited_p50": null, "edited_p95": null, "se
{"summary": true, "doc": "plain-1000", "engine": "ref", "tag": "mode-ref-high-performance", "pages_typed": "0,300,600,999", "profile": "high-performance", "keys": 37, "peak_rss": 690241536, "peak_rss_sampled": 690241536, "peak_rss_kernel": 535579328, "killed_at_limit": false, "edited_p50": 12.023875
{"summary": true, "doc": "full-1000", "engine": "ref", "tag": "mode-ref-high-performance", "pages_typed": "0,300,600,999", "profile": "high-performance", "keys": 37, "peak_rss": 872628224, "peak_rss_sampled": 872628224, "peak_rss_kernel": 700517440, "killed_at_limit": false, "edited_p50": 20.5900000
{"summary": true, "doc": "infdesc-x2", "engine": "ref", "tag": "mode-ref-high-performance", "pages_typed": "110,270", "profile": "high-performance", "keys": 3, "peak_rss": 1569390592, "peak_rss_sampled": 1569390592, "peak_rss_kernel": 1503172800, "killed_at_limit": false, "edited_p50": null, "edited
| doc | engine | mode | keys | peak RSS MB | logs MB (end) | ckpts (end) | to edited page p50 / p95 M | restore p50 M | compile p50 / p95 M | edited ms p50 / p95 |
|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | ref | low-memory | 32 | 543 | 64 | 244 |  /  |  |  /  | 24.1 / 870.1 |
| full-1000 | ref | balanced | 32 | 667 | 272 | 1028 |  /  |  |  /  | 19.6 / 53.8 |
| full-1000 | ref | high-performance | 32 | 832 | 280 | 1159 |  /  |  |  /  | 21.4 / 76.5 |
| infdesc-x2 | ref | low-memory | 0 | 445 | 6 | 15 |  /  |  |  /  |  |
| infdesc-x2 | ref | balanced | 0 | 1119 | 579 | 1660 |  /  |  |  /  |  |
| infdesc-x2 | ref | high-performance | 0 | 1497 | 833 | 6496 |  /  |  |  /  |  |
| plain-1000 | ref | low-memory | 32 | 485 | 58 | 266 |  /  |  |  /  | 16.4 / 337.9 |
| plain-1000 | ref | balanced | 32 | 569 | 219 | 1010 |  /  |  |  /  | 11.8 / 46.9 |
| plain-1000 | ref | high-performance | 32 | 658 | 222 | 1074 |  /  |  |  /  | 12.2 / 34.6 |
```
```
shard modes, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T20:49:41Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 49.16 22.80 9.18 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 2.36 6.61 8.63 }
```
