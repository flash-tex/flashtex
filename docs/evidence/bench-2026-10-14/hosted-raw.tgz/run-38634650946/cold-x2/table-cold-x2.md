## cold-x2

| document | n | flashtex-v3 build p50 / p95 | pdflatex one pass p50 / p95 | latexmk p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk | engine one pass p50 / p95 | engine latexmk p50 / p95 | engine-mk output |
|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---|
| infdesc-x2 | 0 | failed | 56.44 s / 63.84 s | 162.82 s / 183.13 s (3) | - | - | byte-identical but the trailer /ID | 47.90 s / 66.34 s | 152.38 s / 177.15 s | byte-identical |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | pdflatex | latexmk | engine | engine-mk | v3 passes (--progress) |
|---|---:|---:|---:|---:|---:|---|
| infdesc-x2 | 1158 MB | 82 MB | 99 MB | 127 MB | 98 MB | flashtex-v3: wrote v3-out.pdf (346323 ms) |

Failed timed runs: {('infdesc-x2', 'v3'): 7}
```
shard cold-x2, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T20:51:26Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 63.84 24.48 9.57 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 1.58 1.47 1.47 }
```
