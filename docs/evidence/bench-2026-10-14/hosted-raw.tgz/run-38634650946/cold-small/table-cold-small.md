## cold-small

| document | n | flashtex-v3 build p50 / p95 | pdflatex one pass p50 / p95 | latexmk p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk | engine one pass p50 / p95 | engine latexmk p50 / p95 | engine-mk output |
|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---|
| hw1 | 7 | 791 ms / 947 ms | 657 ms / 830 ms | 1.60 s / 1.78 s (2) | 0.83× | 2.03× | byte-identical but the trailer /ID | 208 ms / 246 ms | 663 ms / 745 ms | byte-identical |
| hw2 | 7 | 641 ms / 781 ms | 539 ms / 599 ms | 1.20 s / 1.29 s (2) | 0.84× | 1.87× | byte-identical but the trailer /ID | 162 ms / 209 ms | 536 ms / 642 ms | byte-identical |
| plain-100 | 7 | 2.24 s / 2.59 s | 708 ms / 881 ms | 1.52 s / 2.19 s (2) | 0.32× | 0.68× | byte-identical but the trailer /ID | 324 ms / 485 ms | 886 ms / 1.13 s | byte-identical |
| plain-300 | 7 | 5.32 s / 5.67 s | 1.14 s / 1.31 s | 2.51 s / 2.92 s (2) | 0.21× | 0.47× | byte-identical but the trailer /ID | 750 ms / 914 ms | 1.75 s / 1.90 s | byte-identical |
| full-100 | 7 | 5.08 s / 5.79 s | 2.00 s / 2.42 s | 4.24 s / 4.64 s (2) | 0.39× | 0.83× | byte-identical but the trailer /ID | 1.06 s / 1.20 s | 3.68 s / 4.08 s | byte-identical |
| beamer-5 | 7 | 1.86 s / 2.16 s | 1.07 s / 1.18 s | 2.45 s / 3.43 s (2) | 0.57× | 1.32× | byte-identical but the trailer /ID | 600 ms / 665 ms | 2.26 s / 2.36 s | byte-identical |
| beamer-30 | 7 | 8.14 s / 8.92 s | 2.87 s / 3.49 s | 5.96 s / 7.66 s (2) | 0.35× | 0.73× | byte-identical but the trailer /ID | 2.34 s / 2.74 s | 7.25 s / 8.56 s | byte-identical |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | pdflatex | latexmk | engine | engine-mk | v3 passes (--progress) |
|---|---:|---:|---:|---:|---:|---|
| hw1 | 204 MB | 47 MB | 68 MB | 48 MB | 73 MB | flashtex-v3: wrote v3-out.pdf (936 ms) |
| hw2 | 147 MB | 53 MB | 64 MB | - | 74 MB | flashtex-v3: wrote v3-out.pdf (689 ms) |
| plain-100 | 200 MB | 51 MB | 67 MB | 55 MB | 71 MB | flashtex-v3: wrote v3-out.pdf (1823 ms) |
| plain-300 | 305 MB | 51 MB | 67 MB | 55 MB | 71 MB | flashtex-v3: wrote v3-out.pdf (5706 ms) |
| full-100 | 244 MB | 54 MB | 70 MB | 60 MB | 76 MB | flashtex-v3: wrote v3-out.pdf (4893 ms) |
| beamer-5 | 170 MB | 55 MB | 72 MB | 62 MB | 78 MB | flashtex-v3: wrote v3-out.pdf (1680 ms) |
| beamer-30 | 202 MB | 56 MB | 72 MB | 62 MB | 78 MB | flashtex-v3: wrote v3-out.pdf (7178 ms) |
```
shard cold-small, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T21:21:17Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 15.88 22.05 10.75 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 7.06 12.03 11.41 }
```
