## cold-infdesc

| document | n | flashtex-v3 build p50 / p95 | pdflatex one pass p50 / p95 | latexmk p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk | engine one pass p50 / p95 | engine latexmk p50 / p95 | engine-mk output |
|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---|
| infdesc | 0 | failed | 23.39 s / 28.06 s | 71.90 s / 83.99 s (3) | - | - | byte-identical but the trailer /ID | 19.39 s / 24.77 s | 63.46 s / 71.48 s | byte-identical |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | pdflatex | latexmk | engine | engine-mk | v3 passes (--progress) |
|---|---:|---:|---:|---:|---:|---|
| infdesc | 660 MB | 79 MB | 96 MB | 124 MB | 94 MB | flashtex-v3: wrote v3-out.pdf (116899 ms) |

Failed timed runs: {('infdesc', 'v3'): 7}
```
shard cold-infdesc, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T20:49:41Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 34.89 14.87 5.90 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 1.40 1.68 2.86 }
```
