## cold-1000

| document | n | flashtex-v3 build p50 / p95 | pdflatex one pass p50 / p95 | latexmk p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk | engine one pass p50 / p95 | engine latexmk p50 / p95 | engine-mk output |
|---|---:|---:|---:|---:|---:|---:|---|---:|---:|---|
| plain-1000 | 7 | 14.59 s / 16.84 s | 2.40 s / 2.54 s | 4.91 s / 5.60 s (2) | 0.16× | 0.34× | byte-identical but the trailer /ID | 1.81 s / 1.94 s | 4.09 s / 4.90 s | byte-identical |
| full-1000 | 7 | 52.98 s / 61.31 s | 12.10 s / 14.67 s | 37.92 s / 50.98 s (3) | 0.23× | 0.72× | byte-identical but the trailer /ID | 6.54 s / 8.20 s | 19.82 s / 23.07 s | byte-identical |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | pdflatex | latexmk | engine | engine-mk | v3 passes (--progress) |
|---|---:|---:|---:|---:|---:|---|
| plain-1000 | 672 MB | 51 MB | 68 MB | 109 MB | 71 MB | flashtex-v3: wrote v3-out.pdf (24368 ms) |
| full-1000 | 780 MB | 55 MB | 73 MB | 61 MB | 79 MB | flashtex-v3: wrote v3-out.pdf (53322 ms) |
```
shard cold-1000, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T20:51:29Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 47.91 36.47 16.00 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 2.14 4.17 8.01 }
```
