## unicode

| document | n | flashtex-v3 build p50 / p95 | xelatex one pass p50 / p95 | latexmk -xelatex p50 / p95 (passes) | v3 vs one pass | v3 vs latexmk | v3 output vs latexmk |
|---|---:|---:|---:|---:|---:|---:|---|
| b01 | 9 | 492 ms / 658 ms | 712 ms / 787 ms | 1.17 s / 1.66 s (2) | 1.45× | 2.38× | MISMATCH |
| b02 | 9 | 1.08 s / 1.25 s | 1.06 s / 1.20 s | 1.50 s / 1.90 s (2) | 0.98× | 1.39× | MISMATCH |
| b03 | 9 | 2.08 s / 2.52 s | 1.15 s / 1.30 s | 2.10 s / 2.57 s (2) | 0.56× | 1.01× | MISMATCH |
| b04 | 9 | 1.26 s / 1.40 s | 633 ms / 751 ms | 1.53 s / 1.87 s (3) | 0.50× | 1.22× | MISMATCH |

Ratios are the other engine's median over v3's: above 1× v3 is faster, below 1× slower.

Peak resident memory of the whole process tree, warm-up run (ps every 100 ms):

| document | v3 | xelatex | latexmk | v3 passes (--progress) |
|---|---:|---:|---:|---|
| b01 | 213 MB | 204 MB | 186 MB | flashtex-v3: wrote v3-out.pdf (313 ms) |
| b02 | 219 MB | 214 MB | 194 MB | flashtex-v3: wrote v3-out.pdf (1446 ms) |
| b03 | 226 MB | 207 MB | 198 MB | flashtex-v3: wrote v3-out.pdf (1750 ms) |
| b04 | 232 MB | 190 MB | 195 MB | flashtex-v3: wrote v3-out.pdf (1417 ms) |
unicode-keys-b01-article.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 5.0, "edited_ms": 5.0, "done_ms": 8.4, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 129.5, "peak_mb": 204.2, "sources": 1}

unicode-keys-b02-georgia.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 3.2, "edited_ms": 3.2, "done_ms": 5.8, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 130.0, "peak_mb": 205.4, "sources": 1}

unicode-keys-b03-unicode-math.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 1, "first_ms": 8.6, "edited_ms": 8.6, "done_ms": 12.2, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["s0"], "footprint_mb": 139.7, "peak_mb": 213.2, "sources": 1}

unicode-keys-b04-fontspec-11pages.jsonl:
{"tag": "key40", "status": "ok", "passes": 1, "pages": 11, "first_ms": 2.8, "edited_ms": 7.9, "done_ms": 21.9, "instructions_m": 0.0, "edited_instructions_m": null, "first_instructions_m": null, "cg_dumps": null, "mode": "incremental", "starts": ["page"], "footprint_mb": 139.2, "peak_mb": 214.2, "sources": 11}

```
shard unicode, commit da192316120e8e96a00a96a21f53ec9d862b3abe, 2026-10-14T20:49:42Z
ProductName:		macOS ProductVersion:		15.7.9 BuildVersion:		24G830 
VirtualMac2,1 Apple M1 (Virtual) 3 7516192768 
{ 11.03 20.89 10.73 }
/dev/disk2s1s1   320Gi    10Gi    42Gi    20%    427k  441M    0%   /
rustc 1.99.0 (b940084d7 2026-09-28)
cargo 1.99.0 (5f94df478 2026-08-27)
da192316120e8e96a00a96a21f53ec9d862b3abe
[32m==>[0m [1mmactex-no-gui[0m (MacTeX): 2026.0324
Full TeX Live distribution without GUI applications
[4mhttps://www.tug.org/mactex/[24m
pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026)
XeTeX 3.141592653-2.6-0.999998 (TeX Live 2026)
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/pdflatex.ini
/usr/local/texlive/2026/texmf-dist/tex/latex/tex-ini-files/xelatex.ini
{ 3.02 4.87 6.92 }
```
