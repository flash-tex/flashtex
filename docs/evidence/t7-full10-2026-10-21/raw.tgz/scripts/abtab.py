import json, sys, os, glob, statistics as S
# abtab.py OUTDIR... : per run dir and phase: n, edited ms p50/p95/max, first page instr p50, typeset instr p50,
# restore instr p50, first_page_sys p50, first_page_cpu p50
def pct(v, q):
    v = sorted(v)
    if not v:
        return float('nan')
    k = (len(v) - 1) * q
    f = int(k); c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)
pooled = {}
for d in sys.argv[1:]:
    for f in sorted(glob.glob(f'{d}/raw/*.jsonl')):
        ph = os.path.basename(f)[:-6]
        rows = [json.loads(l) for l in open(f)]
        rows = [r for r in rows if 'key' in r and 'host' in r and r.get('edited_page_ms') is not None]
        rows = rows[1:]  # drop key 0 (t7 measures 19 of 20)
        eng = d.rstrip('/').split('-')[-1]
        p = pooled.setdefault((ph, eng), [])
        p.extend(rows)
for (ph, eng), rows in sorted(pooled.items()):
    if not rows: continue
    ms = [r['edited_page_ms'] for r in rows]
    st = [r['host']['stages'] for r in rows]
    g = lambda k: S.median([s.get(k) or 0 for s in st])
    print(f"{ph:28s} {eng:6s} n={len(rows):3d} ms {pct(ms,.5):5.2f} / {pct(ms,.95):5.2f} / {max(ms):5.2f}"
          f"  fp_instr {g('first_page_instr_k')/1000:6.1f}M ts_instr {g('typeset_instr_k')/1000:6.1f}M"
          f" restore {g('restore_instr_k')/1000:5.2f}M fp_sys {g('first_page_sys'):5.0f} fp_cpu {g('first_page_cpu'):5.2f}"
          f" apply {g('apply'):5.3f}")
