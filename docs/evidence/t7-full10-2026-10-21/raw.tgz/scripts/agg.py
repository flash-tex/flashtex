import sys, re, collections
# strace -f -k (no timestamps): windows between mark writes write(10, "X", 1) on the engine thread;
# aggregate syscalls by (name, the first two flashtex frames).
f = sys.argv[1]
want = int(sys.argv[2]) if len(sys.argv) > 2 else -1   # which keystroke (count of 'b' marks)
lines = open(f, errors='replace').read().splitlines()
recs = []
cur = None
for l in lines:
    if l.startswith(' > '):
        if cur is not None:
            m = re.search(r'\(([^+()]+)\+0x', l)
            if m:
                cur[2].append(m.group(1))
        continue
    p = l.split(' ', 1)
    if len(p) < 2 or not p[0].isdigit():
        cur = None
        continue
    m = re.match(r'(\w+)\(', p[1])
    if not m:
        cur = None
        continue
    cur = [p[0], m.group(1), [], p[1]]
    recs.append(cur)

def short(fn):
    out=[]; i=0
    while i < len(fn):
        if fn[i].isdigit() and (i==0 or not fn[i-1].isdigit()):
            j=i
            while j<len(fn) and fn[j].isdigit(): j+=1
            n=int(fn[i:j])
            if 0<n<=len(fn)-j and (fn[j].isalpha() or fn[j]=='_'):
                ident=fn[j:j+n]
                if not ident.startswith('_') or len(out)==0:
                    out.append(ident)
                i=j+n; continue
            i=j; continue
        i+=1
    out=[o for o in out if o not in ('flashtex_engine','flashtex_runtime','generated','globals','Globals','body_3','body_7','std','sys')]
    return '::'.join(out[-2:]) if out else fn

win = None
nb = 0
agg = collections.Counter()
tot = collections.Counter()
for r in recs:
    tid, name, frames, text = r
    mm = re.match(r'write\(10, "([abde])", 1', text)
    if mm:
        k = mm.group(1)
        if k == 'a':
            nb += 1
        win = k
        continue
    if want >= 0 and nb != want:
        continue
    fl = [short(x) for x in frames if 'flashtex' in x or 'kpse' in x or 'kpathsea' in x]
    key = (win, name, ' < '.join(fl[:3]))
    agg[key] += 1
    tot[(win, name)] += 1
for w in 'abde':
    s = sum(v for (ww, n), v in tot.items() if ww == w)
    print(f'== window {w}: {s}')
    for (ww, n, c), v in sorted(agg.items(), key=lambda x: -x[1]):
        if ww == w and v >= 3:
            print(f'{v:5d} {n:12s} {c[:230]}')
