import json, sys
for f in sys.argv[1:]:
    rows = [json.loads(l) for l in open(f)]
    rows = [r for r in rows if 'key' in r]
    print(f.split('/')[-1])
    for r in rows:
        st = r['host']['stages']
        print(r['key'], round(r['edited_page_ms'], 2), 'apply', st['apply'], st.get('apply_us'), 'pin', st.get('apply_pin'), st.get('pin'),
              'restore', st['restore'], 'fp', st['first_page'], 'fpcpu', st['first_page_cpu'], 'fpsys', st.get('first_page_sys'),
              'q', st['queue'], 'fpi', st.get('first_page_instr_k'))
