import sys, re, collections
# strace -f -ttt: count syscalls (all threads) between each "b NS" and "e NS" mark write; also a..b
f = sys.argv[1]
lines = open(f).read().splitlines()
state = None
wins = []
cur = None
for l in lines:
    m = re.search(r'write\(10, "([abde])", 1\)', l)
    if m:
        k = m.group(1)
        if cur is not None:
            wins.append(cur)
        cur = (k, collections.Counter(), collections.Counter())
        continue
    if cur is None:
        continue
    p = l.split(' ', 2)
    if len(p) < 3:
        continue
    tid, rest = p[0], p[2]
    m = re.match(r'(<\.\.\. )?(\w+)', rest)
    if not m:
        continue
    name = m.group(2)
    if rest.startswith('<...'):
        continue  # resumed
    cur[1][name] += 1
    cur[2][tid] += 1
if cur: wins.append(cur)
for k, c, t in wins:
    print(k, sum(c.values()), dict(t.most_common(4)))
    print('   ', c.most_common(14))
