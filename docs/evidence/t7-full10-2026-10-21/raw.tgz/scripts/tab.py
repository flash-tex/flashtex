import json,sys
G=["queue","apply","apply_sys","restore","restore_sys","restore_flt","restore_instr_k","first_page","first_page_cpu","first_page_sys","first_page_flt","first_page_instr_k","typeset_instr_k","test","test_instr_k","find","key","changes","first_page_dl"]
for f in sys.argv[1:]:
    rows=[json.loads(l) for l in open(f)]
    rows=[r for r in rows if "key" in r]
    print(f, len(rows))
    print("key edited", " ".join(G))
    for r in rows:
        st=r["host"]["stages"]
        h=r["host"]
        print(r["key"], round(r.get("edited_page_ms") or 0,2), " ".join(str(st.get(g)) for g in G), "| rp",h["restart_page"], "gap",h["restart_gap"], "ml",h.get("restart_midline"), "ts",h.get("typeset_pages"))
