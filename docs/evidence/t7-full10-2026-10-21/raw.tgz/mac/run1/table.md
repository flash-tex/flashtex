Reference run.

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.1 / 11.8 / 15.0 | p95 | 11 | 11.8 | 33.6 | 1.3 | 19/19 | 2 / 2 | 200 MB | 2.26-2.16 | MISS: p95 11.8 ms > 11 ms |
| full-10 | 11 | letter@middle | 19 | 7.4 / 8.9 / 9.1 | p95 | 11 | 5.1 | 28.6 | 0.7 | 19/19 | 3 / 3 | 200 MB | 2.16-2.15 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
