**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@middle | 19 | 10.0 / 11.3 / 11.4 | p95 | 11 | 11.3 | 330.9 | 0.1 | 19/19 | 33 / 33 | 631 MB | 2.46-2.23 | MISS: p95 11.3 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 11.1 / 13.3 / 13.7 | p95 | 11 | - | - | 0.6 | - | - | 631 MB | 2.23-2.13 | MISS: p95 13.3 ms > 11 ms |
| full-1000 | 1002 | typing@150ms | 39 | 11.3 / 12.6 / 15.0 | p95 | 11 | - | - | 0.7 | - | - | 631 MB | 2.13-2.04 | MISS: p95 12.6 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
