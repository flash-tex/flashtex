**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex-agents.slice throttled 191 of 640 periods (97.8 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 11.3 / 20.1 / 20.5 | p95 | 11 | 20.1 | 69.3 | 0.1 | 19/19 | 2 / 2 | 259 MB | 2.04-1.8 | MISS: p95 20.1 ms > 11 ms |
| beamer-30 | 58 | letter@middle | 19 | 10.5 / 11.4 / 13.4 | p95 | 11 | 11.4 | 61.5 | 0.1 | 19/19 | 2 / 2 | 259 MB | 1.8-1.68 | MISS: p95 11.4 ms > 11 ms |
| beamer-30 | 58 | letter@end | 19 | 10.5 / 14.7 / 15.8 | p95 | 11 | 14.7 | 117.4 | 0.1 | 19/19 | 2 / 2 | 259 MB | 1.68-1.78 | MISS: p95 14.7 ms > 11 ms |
| beamer-30 | 58 | sentence@middle | 19 | 75.8 / 84.9 / 86.5 | p95 | 11 | 84.9 | 312.1 | 68.5 | 19/19 | 2 / 2 | 259 MB | 1.78-1.51 | MISS: p95 84.9 ms > 11 ms |
| beamer-30 | 58 | newline@middle | 19 | 10.5 / 11.8 / 73.8 | p95 | 11 | 11.8 | 292.6 | 0.1 | 19/19 | 3 / 5 | 259 MB | 1.51-1.44 | MISS: p95 11.8 ms > 11 ms |
| beamer-30 | 58 | split@middle | 19 | 9.8 / 11.1 / 11.5 | p95 | 11 | 11.1 | 132.5 | 0.1 | 19/19 | 5 / 5 | 259 MB | 1.44-1.37 | MISS: p95 11.1 ms > 11 ms |
| beamer-30 | 58 | typing@50ms | 39 | 9.1 / 13.3 / 63.4 | p95 | 11 | - | - | 0.1 | - | - | 259 MB | 1.37-1.37 | MISS: p95 13.3 ms > 11 ms; 1 of 39 keystrokes not painted by their own compile |
| beamer-30 | 58 | typing@60ms | 39 | 16.9 / 76.9 / 82.6 | p95 | 11 | - | - | 0.3 | - | - | 259 MB | 1.37-1.42 | MISS: p95 76.9 ms > 11 ms; 9 of 39 keystrokes not painted by their own compile |
| beamer-30 | 58 | typing@150ms | 39 | 10.4 / 50.6 / 58.5 | p95 | 11 | - | - | 0.3 | - | - | 259 MB | 1.42-1.39 | MISS: p95 50.6 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
