**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex-agents.slice throttled 129 of 181 periods (64.4 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 11.2 / 78.8 / 82.9 | p95 | 11 | 78.8 | 191.0 | 64.2 | 19/19 | 2 / 2 | 168 MB | 1.39-1.25 | MISS: p95 78.8 ms > 11 ms |
| full-10 | 11 | letter@middle | 19 | 10.7 / 78.8 / 79.1 | p95 | 11 | 71.3 | 192.5 | 65.4 | 19/19 | 3 / 3 | 168 MB | 1.25-1.15 | MISS: p95 78.8 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
