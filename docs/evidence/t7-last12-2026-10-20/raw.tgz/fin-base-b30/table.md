**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex-agents.slice throttled 393 of 756 periods (243.1 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 17.5 / 18.6 / 20.6 | p95 | 11 | 18.6 | 68.6 | 0.1 | 19/19 | 2 / 2 | 271 MB | 2.2-2.09 | MISS: p95 18.6 ms > 11 ms |
| beamer-30 | 58 | letter@middle | 19 | 15.7 / 90.2 / 96.9 | p95 | 11 | 90.2 | 311.3 | 66.2 | 19/19 | 2 / 2 | 271 MB | 2.09-2.74 | MISS: p95 90.2 ms > 11 ms |
| beamer-30 | 58 | letter@end | 19 | 15.9 / 98.2 / 100.1 | p95 | 11 | 98.2 | 395.4 | 71.2 | 19/19 | 2 / 2 | 271 MB | 2.74-3.26 | MISS: p95 98.2 ms > 11 ms |
| beamer-30 | 58 | sentence@middle | 19 | 16.6 / 94.0 / 96.3 | p95 | 11 | 94.0 | 392.2 | 68.2 | 19/19 | 2 / 2 | 271 MB | 3.26-2.99 | MISS: p95 94.0 ms > 11 ms |
| beamer-30 | 58 | newline@middle | 19 | 93.6 / 98.4 / 100.8 | p95 | 11 | 98.4 | 695.0 | 71.3 | 19/19 | 3 / 5 | 271 MB | 2.99-2.61 | MISS: p95 98.4 ms > 11 ms |
| beamer-30 | 58 | split@middle | 19 | 15.8 / 93.1 / 94.7 | p95 | 11 | 93.1 | 699.2 | 68.2 | 19/19 | 5 / 5 | 271 MB | 2.61-2.71 | MISS: p95 93.1 ms > 11 ms |
| beamer-30 | 58 | typing@50ms | 39 | 13.8 / 14.3 / 14.8 | p95 | 11 | - | - | 0.1 | - | - | 271 MB | 2.71-2.71 | MISS: p95 14.3 ms > 11 ms |
| beamer-30 | 58 | typing@60ms | 39 | 13.9 / 15.0 / 17.8 | p95 | 11 | - | - | 0.1 | - | - | 271 MB | 2.71-2.65 | MISS: p95 15.0 ms > 11 ms |
| beamer-30 | 58 | typing@150ms | 39 | 14.6 / 65.4 / 71.6 | p95 | 11 | - | - | 1.1 | - | - | 271 MB | 2.65-2.68 | MISS: p95 65.4 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
