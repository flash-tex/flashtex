**NON-REFERENCE run**: power source unknown at start; power source unknown at end; CPU quota of flashtex-agents.slice throttled 414 of 780 periods (235.9 s stopped)

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-1000 | 1002 | letter@middle | 19 | 9.6 / 11.5 / 14.1 | p95 | 11 | 11.5 | 328.2 | 0.1 | 19/19 | 33 / 33 | 693 MB | 1.21-1.51 | MISS: p95 11.5 ms > 11 ms |
| full-1000 | 1002 | typing@100ms | 39 | 10.1 / 11.2 / 15.2 | p95 | 11 | - | - | 0.5 | - | - | 693 MB | 1.51-1.47 | MISS: p95 11.2 ms > 11 ms |
| full-1000 | 1002 | typing@150ms | 39 | 10.6 / 11.9 / 12.1 | p95 | 11 | - | - | 0.6 | - | - | 693 MB | 1.47-1.43 | MISS: p95 11.9 ms > 11 ms |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
