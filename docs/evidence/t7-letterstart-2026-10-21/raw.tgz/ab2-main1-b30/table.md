**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| beamer-30 | 58 | letter@start | 19 | 10.9 / 12.9 / 20.2 | p95 | 11 | 12.9 | 59.8 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.6-0.58 | MISS: p95 12.9 ms > 11 ms |
| beamer-30 | 58 | letter@middle | 19 | 9.1 / 10.8 / 14.8 | p95 | 11 | 10.8 | 58.7 | 0.1 | 19/19 | 2 / 2 | 200 MB | 0.58-0.49 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
