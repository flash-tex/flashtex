**NON-REFERENCE run**: power source unknown at start; power source unknown at end

| doc | pages | edit | n | ms p50 / p95 / max | gated on | target | first changed page p95 | DONE p95 ms | off-CPU p95 ms | converged | re-typeset pages p50 / max | host RSS peak | load1 | verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| full-10 | 11 | letter@start | 19 | 9.1 / 10.8 / 10.9 | p95 | 11 | 10.8 | 41.6 | 0.1 | 19/19 | 2 / 2 | 169 MB | 0.61-0.67 | PASS |
| full-10 | 11 | letter@middle | 19 | 8.5 / 9.6 / 9.8 | p95 | 11 | 4.0 | 39.3 | 0.0 | 19/19 | 3 / 3 | 169 MB | 0.67-0.62 | PASS |

ms: COMPILE written to the watched page's PAGE frame read on the socket (preamble, reopen: page 1); typing@: the keystroke sent to the watched page from its own compile or a later one. off-CPU: of the host's time to that page, what its engine thread spent descheduled (wall minus queue minus thread CPU): load or a CPU quota, not the engine. The first sample of each phase is a warm-up, left out; rows with n < 12 are gated on their maximum. No noise margin: a row passes only when it meets its target.
